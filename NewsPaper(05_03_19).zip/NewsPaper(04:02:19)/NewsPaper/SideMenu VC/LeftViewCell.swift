//
//  LeftViewCell.swift
//  LGSideMenuControllerDemo
//

import UIKit

class LeftViewCell: UITableViewCell {


   
    @IBOutlet weak var lblTitle: UILabel!
  
    var simpleImage: UIImage!
    var seldImage: UIImage!
    override func awakeFromNib() {
        super.awakeFromNib()
        backgroundColor = .clear
        lblTitle.font = UIFont.boldSystemFont(ofSize: 20)
        lblTitle.lineBreakMode = .byWordWrapping
        lblTitle.numberOfLines = 3
    }

    func setHighlighted() {
       // lblTitle.textColor = Constants.Color.themeColor
       // menuImage.image = seldImage
    }
    
    func setSimple() {
        //lblTitle.textColor = Constants.Color.fontColor
       // menuImage.image = simpleImage
    }

}
