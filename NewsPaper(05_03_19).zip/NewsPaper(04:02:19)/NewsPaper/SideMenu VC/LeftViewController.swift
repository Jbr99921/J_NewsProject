//
//  LeftViewController.swift
//  LGSideMenuControllerDemo
//
import UIKit

class LeftViewController: UIViewController {
    
    private let titlesArray = ["News", "News in brief", "Buisness", "Window to the World", "Talk", "Good Deed Feed", "Rush-Hour Crush", "60 Seconds", "Guilty", "Escap", "Television", "Metroscope", "Sports", "Tipster", "Caption Competition", "Games", "Puzzel", "Thanks For Reading"]
    
    var menuArray: NSMutableArray = NSMutableArray()
    
    @IBOutlet weak var tblSideMenu: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblSideMenu.contentInset = UIEdgeInsets(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
        NotificationCenter.default.addObserver(self, selector: #selector(ReloadMenu(notification:)), name: NSNotification.Name(rawValue: "NotificationIdentifier"), object: nil)
        
    
        
    }
    @objc func ReloadMenu(notification: NSNotification){

        let array = (UserDefaults.standard.value(forKey: "MenuArray") as! NSArray).mutableCopy() as! NSMutableArray
            print(array)
        menuArray = array .mutableCopy() as! NSMutableArray
        tblSideMenu.reloadData()
        
       /* if array != nil{
            print(array)
            let test = array[0] as! NSMutableArray
            print(test)
            menuArray = test .mutableCopy() as! NSMutableArray
            print(menuArray)
            tblSideMenu.reloadData()
        }*/
       
    }
    override var prefersStatusBarHidden: Bool {
        return true
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }

    override var preferredStatusBarUpdateAnimation: UIStatusBarAnimation {
        return .fade
    }
    @IBAction func btnHomeClicked(_ sender: Any) {
        self.gotToViewControllerFromSideMenu(with: "HomeVC")
    }
    
}

extension LeftViewController: UITableViewDataSource, UITableViewDelegate {
    // MARK: - UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if menuArray.count > 0{
            return (menuArray.value(forKey: "id") as AnyObject) .count
        }else{
            return 0
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "LeftViewCell", for: indexPath) as! LeftViewCell
        //cell.lblTitle.text = titlesArray[indexPath.row]
        
        if menuArray.count > 0{
            cell.lblTitle.text = (menuArray[indexPath.row] as AnyObject) .value(forKey: "title") as? String
        }else{
            cell.lblTitle.text = ""//titlesArray[indexPath.row]
        }
        cell.lblTitle.sizeToFit()
        
        cell.setSimple()
        if indexPath.row == 0 {
            cell.setHighlighted()
        }
        
        return cell
    }
    
    // MARK: - UITableViewDelegate
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 59.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedCell = tableView.cellForRow(at: indexPath) as! LeftViewCell
        //let cell = tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as! LeftViewCell
      //  cell.setSimple()
     //   selectedCell.setHighlighted()
        if menuArray.count > 0{
            
            let pageId = (menuArray[indexPath.row] as AnyObject) .value(forKey: "id") as? NSNumber
            let menuIdStr = "\(pageId)"
            print(menuIdStr)
            
            let indexPath = "\(indexPath.row)"
            
            UserDefaults.standard.set("True", forKey: "IsComeFromMenu")
            UserDefaults.standard.set(indexPath, forKey: "indexPath")
            
           // let str = "\(indexPath)"
        //    let intIndex = Int(str)
         /*   let pageNo = (menuArray[indexPath.row] as AnyObject) .value(forKey: "pages") as? String
            UserDefaults.standard.set(pageNo, forKey: "SectionPageNo")
            UserDefaults.standard.set("True", forKey: "IsComeFromMenu")
            UserDefaults.standard.set(menuIdStr, forKey: "MenuID")*/
            //self.gotToViewControllerFromSideMenu(with: "HomeVC")
        }else{
            let index = indexPath.row + 1
            let indexStr = "\(index)"
            UserDefaults.standard.set(indexStr, forKey: "MenuID")
            //self.gotToViewControllerFromSideMenu(with: "HomeVC")
        }
        self.gotToViewControllerFromSideMenu(with: "HTMLViewerVC")
        /*
        switch indexPath.row {
        case 0:
            self.gotToViewControllerFromSideMenu(with: "HomeVC")
        case 1:
            self.gotToViewControllerFromSideMenu(with: "MySocietyVC")
        case 2:
            self.gotToViewControllerFromSideMenu(with: "ConatctUsVC")
        case 3:
            self.gotToViewControllerFromSideMenu(with: "AttechmentVC")
        case 4:
            self.gotToViewControllerFromSideMenu(with: "HomeVC")
        case 5:
            self.gotToViewControllerFromSideMenu(with: "GroupsVC")
        case 6:
            self.gotToViewControllerFromSideMenu(with: "HomeVC")
        case 7:
            self.gotToViewControllerFromSideMenu(with: "NoticeVC")
        case 8:
            self.gotToViewControllerFromSideMenu(with: "IssuesVC")
        case 9:
            self.gotToViewControllerFromSideMenu(with: "VisitorsVC")
        case 10:
            self.gotToViewControllerFromSideMenu(with: "BellingMainVC")
        case 11:
            self.gotToViewControllerFromSideMenu(with: "BellingMainVC")
        default:
            break
        }*/
        
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
       /* let selectedCell = tableView.cellForRow(at: indexPath) as! LeftViewCell
        selectedCell.setSimple()*/
    }
}

extension LeftViewController {
    func gotToViewControllerFromSideMenu(with storyboardID: String) {
        let mainViewController = sideMenuController!
        let navigationController = mainViewController.rootViewController as! UINavigationController
        
        let viewController = self.storyboard!.instantiateViewController(withIdentifier: storyboardID)
        
        navigationController.setViewControllers([viewController], animated: false)
        
        mainViewController.hideLeftView(animated: true, delay: 0.0, completionHandler: nil)
    }
}
