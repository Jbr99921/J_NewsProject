//
//  SideMenuViewController.swift
//  ConnectingPeople
//
//  Created by Dilip Bakotiya on 05/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//  Created by archirayan on 4/12/18.
//  Author:www.archirayan.com
//  Email:info@archirayan.com
//

import UIKit
import LGSideMenuController

class SideMenuViewController: LGSideMenuController {

    override func viewDidLoad() {
        super.viewDidLoad()
        rightView?.isHidden = true
        leftViewPresentationStyle = .scaleFromBig
    }

    override func leftViewWillLayoutSubviews(with size: CGSize) {
        super.leftViewWillLayoutSubviews(with: size)
        
        if !isLeftViewStatusBarHidden {
            leftView?.frame = CGRect(x: 0.0, y: 20.0, width: size.width, height: size.height - 20.0)
        }
    }
    
    override var isLeftViewStatusBarHidden: Bool {
        get {
            return super.isLeftViewStatusBarHidden
        }
        
        set {
            super.isLeftViewStatusBarHidden = newValue
        }
    }
}
