//
//  SettingVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 05/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//  Created by archirayan on 4/12/18.
//  Author:www.archirayan.com
//  Email:info@archirayan.com
//


import UIKit

class SettingVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    // MARK: - Button Action Method
    @IBAction func backButtonClicked(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    @IBAction func generalButtonClicked(_ sender: Any) {
        let General = self.storyboard?.instantiateViewController(withIdentifier: "GeneralVC") as! GeneralVC
        self.navigationController?.pushViewController(General, animated: true)
    }
    @IBAction func contactUsButtonClicked(_ sender: Any) {
        let ContectUs = self.storyboard?.instantiateViewController(withIdentifier: "ContectUsVC") as! ContectUsVC
        self.navigationController?.pushViewController(ContectUs, animated: true)
    }
    @IBAction func howToUseAppButtonClicked(_ sender: Any) {
        let HowToUseApp = self.storyboard?.instantiateViewController(withIdentifier: "HowToUseAppVC") as! HowToUseAppVC
        self.navigationController?.pushViewController(HowToUseApp, animated: true)
    }
    @IBAction func faqButtonClicked(_ sender: Any) {
        let FAQ = self.storyboard?.instantiateViewController(withIdentifier: "FAQVC") as! FAQVC
        self.navigationController?.pushViewController(FAQ, animated: true)
    }
    @IBAction func privacyButtonClicked(_ sender: Any) {
        let Privacy = self.storyboard?.instantiateViewController(withIdentifier: "PrivacyVC") as! PrivacyVC
        self.navigationController?.pushViewController(Privacy, animated: true)
    }
    @IBAction func logoutBtnClicked(_ sender: Any) {
        UserDefaults.standard.set("False", forKey: Key.is_UserLogin)
        let SignIN = self.storyboard?.instantiateViewController(withIdentifier: "SignINVC") as! SignINVC
        self.navigationController?.pushViewController(SignIN, animated: true)
    }
    

}
