//
//  AllIssuesTableViewCell.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 07/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//

import UIKit

class AllIssuesTableViewCell: UITableViewCell {

    @IBOutlet var getButton: UIButton!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var newsImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
