//
//  allIssuesVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 05/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//  Created by archirayan on 4/12/18.
//  Author:www.archirayan.com
//  Email:info@archirayan.com
//
//
import UIKit
import EVURLCache

class allIssuesVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    var webViewUrlLoad = UIWebView()
    
    var getSectionArray: NSMutableArray = NSMutableArray()
    var DownloadPdfId: String = String()
    let pdfBaseUrl = "http://hire-people.com/host2/news_wp/api/users_pdf/"
    var mainPdfNameStr: String = String()
    
    var sk_data: SKDatabase?
    
    var pdfName: String = String()
    var pdfUrlStr: String = String()
    var PDFId: String = String()
    var PDFName: String = String()
    var PdfImageUrl: String = String()
    var authoreStr: String = String()
    var postDateStr: String = String()
    var statusStr: String = String()
    
    var dataArray: NSMutableArray = NSMutableArray()
    var newsPaperImageArray: NSMutableArray = NSMutableArray()
    
    @IBOutlet var allIssuesTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let reach = Reachability()
        if reach.isConnectedToNetwork() == true {
            GetNewsData()
        }else{
            let userId = UserDefaults.standard.value(forKey: "UserId") as! String
            self.sk_data = SKDatabase(file: "NewsPaperDB.db")
            
            let GetAllIssue = "SELECT * FROM AllIssue where user_id='\(userId)'"
            
            let GetAllIssuedataArray1 = self.sk_data?.lookupAll(forSQL: GetAllIssue)
            
            let GetAllIssuensMutableArray2 = NSMutableArray(array: GetAllIssuedataArray1!)
            dataArray = GetAllIssuensMutableArray2.mutableCopy() as! NSMutableArray
            self.allIssuesTableView.reloadData()
        }
        
    }
    override func viewWillAppear(_ animated: Bool) {
        let reach = Reachability()
        if reach.isConnectedToNetwork() == false {
            let userId = UserDefaults.standard.value(forKey: "UserId") as! String
            self.sk_data = SKDatabase(file: "NewsPaperDB.db")
            
            let GetAllIssue = "SELECT * FROM AllIssue where user_id='\(userId)'"
            
            let GetAllIssuedataArray1 = self.sk_data?.lookupAll(forSQL: GetAllIssue)
            
            let GetAllIssuensMutableArray2 = NSMutableArray(array: GetAllIssuedataArray1!)
            dataArray = GetAllIssuensMutableArray2.mutableCopy() as! NSMutableArray
            self.allIssuesTableView.reloadData()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func GetPDF(){
       
        let downloadingAndGet = self.storyboard?.instantiateViewController(withIdentifier: "DownloadingAndGetVC") as! DownloadingAndGetVC
        downloadingAndGet.pdfName = PDFName
        downloadingAndGet.PDFId = PDFId
        downloadingAndGet.PDFUrl = pdfUrlStr
        downloadingAndGet.pdfImageUrl = PdfImageUrl
        downloadingAndGet.authoreStr = authoreStr
        downloadingAndGet.postDateStr = postDateStr
        downloadingAndGet.statusStr = statusStr
        self.navigationController?.pushViewController(downloadingAndGet, animated: true)
       
    }
    
    func OpenPDF(){
        UserDefaults.standard.set("false", forKey: "IsComeFromMenu")
        UserDefaults.standard.set("True", forKey: "FisrtTime")
        UserDefaults.standard.set("0", forKey: "indexPath")
        let HTMLViewer = self.storyboard?.instantiateViewController(withIdentifier: "HTMLViewerVC") as! HTMLViewerVC
        HTMLViewer.pdfIdStr = PDFId
        self.navigationController?.pushViewController(HTMLViewer, animated: true)
    }
    
    @objc func GetButtonClicked(sender: UIButton){
        PDFName = (dataArray[sender.tag] as AnyObject) .value(forKey: "title") as! String
        PdfImageUrl = (dataArray[sender.tag] as AnyObject) .value(forKey: "image") as? String ?? ""
        authoreStr = (dataArray[sender.tag] as AnyObject) .value(forKey: "author") as! String
        postDateStr = (dataArray[sender.tag] as AnyObject) .value(forKey: "post_date") as! String
        statusStr = (dataArray[sender.tag] as AnyObject) .value(forKey: "status") as! String
        let reach = Reachability()
        if reach.isConnectedToNetwork() == true {
            let pdfIdNumber = (dataArray[sender.tag] as AnyObject) .value(forKey: "id") as! NSNumber
            PDFId = "\(pdfIdNumber)"
        }else{
            PDFId = (dataArray[sender.tag] as AnyObject) .value(forKey: "id") as! String
        }
        GetPDF()
    }
    
    @objc func OpenButtonClicked(sender: UIButton){
        let reach = Reachability()
        if reach.isConnectedToNetwork() == true {
            let pdfIdNumber = (dataArray[sender.tag] as AnyObject) .value(forKey: "id") as! NSNumber
            PDFId = "\(pdfIdNumber)"
        }else{
            PDFId = (dataArray[sender.tag] as AnyObject) .value(forKey: "id") as! String
        }
        OpenPDF()
    }
    
    //MARK: - TableView Deleget Method
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (dataArray .value(forKey: "id") as AnyObject).count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:AllIssuesTableViewCell = tableView.dequeueReusableCell(withIdentifier: "AllIssuesTableViewCell") as! AllIssuesTableViewCell
        
        cell.getButton.tag = indexPath.row
        let status = (dataArray[indexPath.row] as AnyObject).value(forKey: "status") as! String
        //print(status)
        
        if status == "\(0)"{
            cell.getButton.setTitle("GET", for: .normal)
            cell.getButton.addTarget(self, action:  #selector(GetButtonClicked(sender:)), for: .touchUpInside)
        }else{
            cell.getButton.setTitle("OPEN", for: .normal)
            cell.getButton.addTarget(self, action:  #selector(OpenButtonClicked(sender:)), for: .touchUpInside)
        }
        
        cell.dateLabel.text = (dataArray[indexPath.row] as AnyObject) .value(forKey: "post_date") as? String
        
        let reach = Reachability()
        if reach.isConnectedToNetwork() == true {
            let imageUrl = (dataArray[indexPath.row] as AnyObject) .value(forKey: "image_url") as? String ?? ""
            let str = imageUrl.replacingOccurrences(of: " ", with: " ")
            print(str)
            
           if let data = NSData(contentsOf: NSURL(string:str as String )! as URL) {
                cell.newsImageView.image = UIImage(data: data as Data)
            }else{
                cell.newsImageView.image = #imageLiteral(resourceName: "ic_splash_newspaper")
            }
        }else{
            let imageUrl = (dataArray[indexPath.row] as AnyObject) .value(forKey: "image_url") as? String ?? ""
            if let decodedData = Data(base64Encoded: imageUrl, options: .ignoreUnknownCharacters) {
                cell.newsImageView.image = UIImage(data: decodedData)
            }else{
                cell.newsImageView.image = #imageLiteral(resourceName: "ic_splash_newspaper")
            }
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let status = (dataArray[indexPath.row] as AnyObject) .value(forKey: "status") as! String
        if status == "\(0)"{
            PDFName = (dataArray[indexPath.row] as AnyObject) .value(forKey: "title") as! String
            PdfImageUrl = (dataArray[indexPath.row] as AnyObject) .value(forKey: "image_url") as! String
            authoreStr = (dataArray[indexPath.row] as AnyObject) .value(forKey: "author") as! String
            postDateStr = (dataArray[indexPath.row] as AnyObject) .value(forKey: "post_date") as! String
            statusStr = (dataArray[indexPath.row] as AnyObject) .value(forKey: "status") as! String
            let reach = Reachability()
            if reach.isConnectedToNetwork() == true {
                let pdfIdNumber = (dataArray[indexPath.row] as AnyObject) .value(forKey: "id") as! NSNumber
                PDFId = "\(pdfIdNumber)"
            }else{
                 PDFId = (dataArray[indexPath.row] as AnyObject) .value(forKey: "id") as! String
            }
            GetPDF()
        }else{
            let reach = Reachability()
            if reach.isConnectedToNetwork() == true {
                let pdfIdNumber = (dataArray[indexPath.row] as AnyObject) .value(forKey: "id") as! NSNumber
                PDFId = "\(pdfIdNumber)"
            }else{
                PDFId = (dataArray[indexPath.row] as AnyObject) .value(forKey: "id") as! String
            }
            OpenPDF()
        }
        
    }
    
    func GetNewsData(){
        
        ACProgressHUD.shared.showHUD()
        
        DispatchQueue.global(qos: .background).async {
            //http://hire-people.com/host2/News/apis/mainpages2.php?user_id=17&action=main
            
            let myUrl = URL(string: GlobalUrl.BaseUrl + "mainpages2.php?");
            print(myUrl!)
            var request = URLRequest(url:myUrl!)
            request.httpMethod = "POST"
            
            let userId = UserDefaults.standard.value(forKey: "UserId") as! String
            var postString: String = String()
            postString = "user_id=" + userId + "&action=main"
            print(postString)
            
            let userName = "admin"
            let password = "admin"
            var _: Error? = nil
            let authStr = "\(userName):\(password)"
            let authData: Data? = authStr.data(using: .ascii)
            let authStrData = String(data: authData?.base64EncodedData(options: .endLineWithLineFeed) ?? Data(), encoding: .ascii)
            let authValue = "Basic \(authStrData!)"
            request.addValue(authValue, forHTTPHeaderField: "Authorization")
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                
                if error != nil
                {
                    ACProgressHUD.shared.hideHUD()
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error!)
                    
                    return
                }
                
                print("response = \(response!)")
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    DispatchQueue.main.async {
                        
                        if let parseJSON = json {
                            print(parseJSON)
                            let status =   parseJSON["status"] as! String
                            
                            if status == "true"{
                                ACProgressHUD.shared.hideHUD()
                                let dataDic = parseJSON["data"] as AnyObject
                                print(dataDic)
                                self.dataArray = dataDic as! NSMutableArray
                                var imageBase64Str: String = String()
                                var idStr: String = String()
                                var titleStr: String = String()
                                var postDateStr: String = String()
                                var authorStr: String = String()
                                var statusStr: String = String()
                                for i in 0..<self.dataArray.count{
                                    
                                    let imageUrl = (self.dataArray[i] as AnyObject) .value(forKey: "image_url") as? String ?? ""
                                    print(imageUrl)
                                    let str = imageUrl.replacingOccurrences(of: " ", with: " ")
                                    print(str)
                                    
                                    if let data = NSData(contentsOf: NSURL(string:str as String )! as URL) {
                                        imageBase64Str = data.base64EncodedString(options: .lineLength64Characters)
                                        
                                    }
                                    
                                    let id = (self.dataArray[i] as AnyObject) .value(forKey: "id") as! NSNumber
                                    idStr = "\(id)"
                                    titleStr = (self.dataArray[i] as AnyObject) .value(forKey: "title") as? String ?? ""
                                    postDateStr = (self.dataArray[i] as AnyObject) .value(forKey: "post_date") as? String ?? ""
                                    authorStr = (self.dataArray[i] as AnyObject) .value(forKey: "author") as? String ?? ""
                                    statusStr = (self.dataArray[i] as AnyObject) .value(forKey: "status") as? String ?? ""
                                    
                                    self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                    
                                    let Premimum = "SELECT * FROM AllIssue where id='\(idStr)' and user_id='\(userId)'"
                                    
                                    let dataArray1 = self.sk_data?.lookupAll(forSQL: Premimum)
                                    
                                    let nsMutableArray5 = NSMutableArray(array: dataArray1!)
                                    
                                    let array = nsMutableArray5 .mutableCopy() as! NSMutableArray
                                    if array.count == 0{
                                        self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                        let InsertAllIssue = "insert into AllIssue (id,title,image_url,post_date,author,status,user_id) VALUES ('\(idStr)','\(titleStr)','\(imageBase64Str)','\(postDateStr)','\(authorStr)','\(statusStr)','\(userId)')"
                                        let st1: Bool =  ((self.sk_data?.performSQL(InsertAllIssue)) != nil)
                                        if st1 {
                                            print("Data Insert")
                                        }
                                        else {
                                            print("Data Not Insert")
                                        }
                                        
                                    }else{
                                        self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                        let updateAllIssue = "UPDATE AllIssue SET title='\(titleStr)',image_url='\(imageBase64Str)',post_date='\(postDateStr)',author='\(authorStr)',status='\(statusStr)' WHERE id='\(idStr)' and user_id='\(userId)'"
                                        self.sk_data?.performSQL(updateAllIssue)
                                        
                                    }
                                    
                                }
                                
                                let firstTimeInstallCheck = UserDefaults.standard.value(forKey: "FirstTimeInstall") as? String ?? "True"
                                if firstTimeInstallCheck == "False"{
                                    UserDefaults.standard.set("False", forKey: "FirstTimeInstall")
                                    let myGroup = DispatchGroup()
                                    for j in 0..<self.dataArray.count{
                                        let statusStr = (self.dataArray[j] as AnyObject) .value(forKey: "status") as? String ?? ""
                                        print(statusStr)
                                        if statusStr == "1"{

                                            let id = (self.dataArray[j] as AnyObject) .value(forKey: "id") as! NSNumber
                                            self.DownloadPdfId = "\(id)"
                                            
                                            // DispatchQueue.main.async(execute: {
                                                self.GetSection()
                                            //})
                                        }
                                    }
                                }
                                
                                
                                if self.dataArray.count == 0{
                                    let alert = UIAlertController(title: "Alert", message:"News Not Found", preferredStyle:     UIAlertControllerStyle.alert)
                                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                
                              
                                
                                self.allIssuesTableView.reloadData()
                                
                            }else{
                                ACProgressHUD.shared.hideHUD()
                                let alert = UIAlertController(title: "ERROR", message:"News Not Found", preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                                
                            }
                        }
                    }
                }
                catch {
                    ACProgressHUD.shared.hideHUD()
                    
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error)
                }
            }
            task.resume()
        }
    }
    
    
    //MARK: - Get Section PDF
    func GetSection(){
        
        ACProgressHUD.shared.showHUD()
        
        DispatchQueue.global(qos: .background).async {
            //http://hire-people.com/host2/news_wp/api/subpages.php?news_id=132
            
            let myUrl = URL(string: GlobalUrl.BaseUrl + "subpages.php?");
            var request = URLRequest(url:myUrl!)
            request.httpMethod = "POST"
            let userId = UserDefaults.standard.value(forKey: "UserId") as! String
            
            let postString = "news_id=" + self.DownloadPdfId
            print(postString)
            let userName = "admin"
            let password = "admin"
            var _: Error? = nil
            let authStr = "\(userName):\(password)"
            let authData: Data? = authStr.data(using: .ascii)
            let authStrData = String(data: authData?.base64EncodedData(options: .endLineWithLineFeed) ?? Data(), encoding: .ascii)
            let authValue = "Basic \(authStrData!)"
            request.addValue(authValue, forHTTPHeaderField: "Authorization")
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                
                if error != nil
                {
                    ACProgressHUD.shared.hideHUD()
                   /* let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error!)*/
                    
                    return
                }
                
                print("response = \(response!)")
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    DispatchQueue.main.async {
                        
                        if let parseJSON = json {
                            
                            print(parseJSON)
                            let status =   parseJSON["status"] as! String
                            
                            if status == "true"{
                                ACProgressHUD.shared.hideHUD()
                                let dataDic = parseJSON["data"] as AnyObject
                                self.getSectionArray = dataDic as! NSMutableArray
                                
                                var idStr: String = String()
                                var titleStr: String = String()
                                var post_url: String = String()
                                
                                for i in 0..<self.getSectionArray.count{
                                    let id = (self.getSectionArray[i] as AnyObject) .value(forKey: "id") as! NSNumber
                                    idStr = "\(id)"
                                    titleStr = (self.getSectionArray[i] as AnyObject) .value(forKey: "title") as? String ?? ""
                                    post_url = (self.getSectionArray[i] as AnyObject) .value(forKey: "post_url") as? String ?? ""
                                     DispatchQueue.main.async(execute: {
                                        let url = URL(string: post_url)
                                        let request1 = URLRequest(url: url!)
                                        URLCache.shared.cachedResponse(for: request1)
                                        self.webViewUrlLoad.loadRequest(URLRequest(url: url!))
                                     })
                                    
                                    self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                    
                                    let Premimum = "SELECT * FROM MenuTbl where id='\(idStr)' and news_id='\(self.PDFId)'"
                                    
                                    let dataArray1 = self.sk_data?.lookupAll(forSQL: Premimum)
                                    
                                    let nsMutableArray5 = NSMutableArray(array: dataArray1!)
                                    
                                    let array = nsMutableArray5 .mutableCopy() as! NSMutableArray
                                    if array.count == 0{
                                        self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                        let InsertAllIssue = "insert into MenuTbl (id,title,post_url,news_id) VALUES ('\(idStr)','\(titleStr)','\(post_url)','\(self.DownloadPdfId)')"
                                        let st1: Bool =  ((self.sk_data?.performSQL(InsertAllIssue)) != nil)
                                        if st1 {
                                            print("Data Insert")
                                        }
                                        else {
                                            print("Data Not Insert")
                                        }
                                        
                                    }else{
                                        self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                        let updateAllIssue = "UPDATE MenuTbl SET title='\(titleStr)',post_url='\(post_url)' WHERE id='\(idStr)' and news_id='\(self.DownloadPdfId)'"
                                        print(updateAllIssue)
                                        self.sk_data?.performSQL(updateAllIssue)
                                        
                                    }
                                }
                               
                                
                                let news = "news"
                                for i in 0..<self.getSectionArray.count{
                                    let pageId = (self.getSectionArray[i] as AnyObject) .value(forKey: "id") as! NSNumber
                                    let combine = news + "\(pageId)"
                                    print(combine)
                                    let createPdfUrlStr = self.pdfBaseUrl + combine + "-" + self.DownloadPdfId + ".pdf"
                                    print(createPdfUrlStr)
                                    let pdfNameStr = combine + "-" + self.DownloadPdfId + ".pdf"
                                    print(pdfNameStr)
                                    self.mainPdfNameStr = pdfNameStr
                                    let urlString = createPdfUrlStr.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
                                    self.savePdf(urlString: urlString!, fileName: self.mainPdfNameStr)
                                }
                                
                            }else{
                                ACProgressHUD.shared.hideHUD()
                              /*  let alert = UIAlertController(title: "ERROR", message:"Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)*/
                                
                            }
                        }
                    }
                }
                catch {
                    ACProgressHUD.shared.hideHUD()
                    
                   /* let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error)*/
                }
            }
            task.resume()
        }
    }
    //MARK:- WebView Methods
    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        if let redirectURL = EVURLCache.shouldRedirect(request: request) {
            let r = URLRequest(url: redirectURL)
            webView.loadRequest(r)
            return false
        }
        return true
    }
    
    //MARK: - Downloding
    func savePdf(urlString:String, fileName:String) {
        DispatchQueue.main.async {
            let url = URL(string: urlString)
            let pdfData = try? Data.init(contentsOf: url!)
            let resourceDocPath = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last! as URL
            let pdfNameFromUrl = fileName
            let actualPath = resourceDocPath.appendingPathComponent(pdfNameFromUrl)
            do {
                try pdfData?.write(to: actualPath, options: .atomic)
              //  ACProgressHUD.shared.hideHUD()
                print("pdf successfully saved!")
              //  self.downloadindAndCancelView.isHidden = true
             //   self.getView.isHidden = false
            } catch {
                print("Pdf could not be saved")
            //    ACProgressHUD.shared.hideHUD()
                let alert = UIAlertController(title: "", message: "Pdf could not be saved", preferredStyle:     UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
}
