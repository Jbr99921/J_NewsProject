//
//  DisplayPDFVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 11/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//

import UIKit
import PDFKit
import QuickLook


class DisplayPDFVC: UIViewController {
     let fileURL3 = Bundle.main.url(forResource: "http://hire-people.com/host2/News/admin/pdffile/news.pdf", withExtension:"pdf")
    
    var imageArray: NSMutableArray = NSMutableArray()
    var pdfIdStr: String = String()
    var indexPathInt: Int = Int()
    var pagenumber: Int = Int()
    let animationDuration: TimeInterval = 0.25
    
    var newsSectionArray: NSMutableArray = NSMutableArray()
    
    @IBOutlet var PDFDisplayView: PDFView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        let firstTime = UserDefaults.standard.value(forKey: "FisrtTime") as? String ?? "True"
        if firstTime == "True"{
            GetNewsData()
        }else{
            let pageNo = UserDefaults.standard.value(forKey: "SectionPageNo") as? String ?? "1"
            var pageNoInt = Int(pageNo)
            pageNoInt = pageNoInt! - 1
            let url = UserDefaults.standard.value(forKey: "PDFUrl") as! String
            self.PDFDisplayView.layoutDocumentView()
            
            let pdf_url : NSURL = NSURL(string: url)!
            print(pdf_url)
            
            let doc = PDFDocument(url: pdf_url as URL)
            self.PDFDisplayView.document = doc
        
            self.PDFDisplayView.autoScales = true
            self.PDFDisplayView.setNeedsLayout()
            self.PDFDisplayView.displayDirection = .horizontal
            self.PDFDisplayView.displayMode = .singlePage
            self.PDFDisplayView.interpolationQuality = .low
            self.PDFDisplayView.maxScaleFactor = 4.0
            self.PDFDisplayView.minScaleFactor = self.PDFDisplayView.scaleFactorForSizeToFit
            self.PDFDisplayView.usePageViewController(true, withViewOptions: [:])
            if let page = PDFDisplayView.document?.page(at: pageNoInt!){
                PDFDisplayView.go(to: page)
            }
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Get News data
    func GetNewsData(){
        
        ACProgressHUD.shared.showHUD()
        
        DispatchQueue.global(qos: .background).async {
            //http://easydatasearch.com/easydata1/News/apis/pdf_sections.php?id=25
            
            let myUrl = URL(string: GlobalUrl.BaseUrl + "pdf_sections.php?");
            var request = URLRequest(url:myUrl!)
            request.httpMethod = "POST"
            
            let postString = "id=" + self.pdfIdStr
            
            let userName = "admin"
            let password = "admin"
            var _: Error? = nil
            let authStr = "\(userName):\(password)"
            let authData: Data? = authStr.data(using: .ascii)
            let authStrData = String(data: authData?.base64EncodedData(options: .endLineWithLineFeed) ?? Data(), encoding: .ascii)
            let authValue = "Basic \(authStrData!)"
            request.addValue(authValue, forHTTPHeaderField: "Authorization")
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                
                if error != nil
                {
                    ACProgressHUD.shared.hideHUD()
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error!)
                    
                    return
                }
                
                print("response = \(response!)")
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    DispatchQueue.main.async {
                        
                        if let parseJSON = json {
                            
                            print(parseJSON)
                            let status =   parseJSON["status"] as! String
                            
                            if status == "true"{
                                ACProgressHUD.shared.hideHUD()
                                let dataArray = parseJSON["data"] as AnyObject
                            
                                
                                let PdfUrl = (dataArray[0] as AnyObject) .value(forKey: "pdf_data") as! String
                                print(PdfUrl)
                                let urlString = PdfUrl.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
                                
                                UserDefaults.standard.set(urlString, forKey: "PDFUrl")
                                self.newsSectionArray = (dataArray[0] as AnyObject) .value(forKey: "section") as! NSMutableArray
                               print(self.newsSectionArray)
                            
                                UserDefaults.standard.setValue(self.newsSectionArray, forKey: "MenuArray")
                                
                                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "NotificationIdentifier"), object: nil)
                                
                                self.PDFDisplayView.layoutDocumentView()
                                
                                let pdf_url : NSURL = NSURL(string: urlString!)!
                                print(pdf_url)
                               
                                let doc = PDFDocument(url: pdf_url as URL)
                                self.PDFDisplayView.document = doc
                                self.PDFDisplayView.autoScales = true
                                self.PDFDisplayView.setNeedsLayout()
                                self.PDFDisplayView.displayDirection = .horizontal
                                self.PDFDisplayView.displayMode = .singlePage
                                self.PDFDisplayView.interpolationQuality = .none
                                self.PDFDisplayView.maxScaleFactor = 4.0
                                self.PDFDisplayView.minScaleFactor = self.PDFDisplayView.scaleFactorForSizeToFit
                                self.PDFDisplayView.usePageViewController(true, withViewOptions: [:])
                            
                                UserDefaults.standard.set("false", forKey: "FisrtTime")
                                
                            }else{
                                ACProgressHUD.shared.hideHUD()
                                let alert = UIAlertController(title: "ERROR", message:"Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                            }
                        }
                    }
                }
                catch {
                    ACProgressHUD.shared.hideHUD()
                    
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error)
                }
            }
            task.resume()
        }
    }
    func drawPDFfromURL(url: URL) -> UIImage? {
        guard let document = CGPDFDocument(url as CFURL) else { return nil }
        guard let page = document.page(at: pagenumber) else { return nil }
        
        let pageRect = page.getBoxRect(.mediaBox)
        let renderer = UIGraphicsImageRenderer(size: pageRect.size)
        let img = renderer.image { ctx in
            UIColor.white.set()
            ctx.fill(pageRect)
            
            ctx.cgContext.translateBy(x: 0.0, y: pageRect.size.height)
            ctx.cgContext.scaleBy(x: 1.0, y: -1.0)
            
            ctx.cgContext.drawPDFPage(page)
        }
        
        return img
    }
    
}
