//
//  HomeVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 05/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//  Created by archirayan on 4/12/18.
//  Author:www.archirayan.com
//  Email:info@archirayan.com
//
//

import UIKit
import EVURLCache

class HomeVC: UIViewController, UIWebViewDelegate {
    
    var webViewUrlLoad = UIWebView()
    var image: UIImage = UIImage()
    var imagePath: String = String()
    
    var sk_data: SKDatabase?

    @IBOutlet var downloadedButton: UIButton!
    @IBOutlet var allIssuesButton: UIButton!
    @IBOutlet var mainScrollView: UIScrollView!
    @IBOutlet var downloadedLineView: UIView!
    @IBOutlet var allIssuesLineView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        webViewUrlLoad.delegate = self
        
    /*    self.sk_data = SKDatabase(file: "NewsPaperDB.db")
        
        let GetDownloadedTbl = "SELECT * FROM MenuTbl"
        
        let GetDownloadeddataArray1 = self.sk_data?.lookupAll(forSQL: GetDownloadedTbl)
        
        print(GetDownloadeddataArray1!)*/
        
        
        // Do any additional setup after loading the view.
        
        //http://hire-people.com/host2/news_wp/main-4/banner14-1/
        let myURLString = "http://hire-people.com/host2/news_wp/main-4/banner14-1/"
        guard let myURL = URL(string: myURLString) else {
            print("Error: \(myURLString) doesn't seem to be a valid URL")
            return
        }
        
        do {
            let myHTMLString = try String(contentsOf: myURL, encoding: .ascii)
            print("HTML : \(myHTMLString)")
            var matched = matches(for: "(http[^\\s]+(jpg|jpeg|png|tiff)\\b)", in: String(myHTMLString))
            print(matched)
            let imageUrl = matched
            print(imageUrl)
            
            //let replace = imageUrl.replacingOccurrences(of: "3.0", with: "4.0")
                
            
            UserDefaults.standard.set(myHTMLString, forKey: "FAQHtml")
        } catch let error {
            print("Error: \(error)")
        }
        
        let str = "http://hire-people.com/host2/news_wp/wp-content/uploads/2019/01/WhatsApp-Image-2019-01-24-at-11.04.29-AM.jpeg"
        if let data = NSData(contentsOf: NSURL(string:str as String )! as URL) {
            image = UIImage(data: data as Data)!
            saveImageToDocumentDirectory(image: image)
        }
       let path = loadImageFromDocumentDirectory(nameOfImage: "WhatsApp-Image-2019-01-24-at-11.04.29-AM.jpeg")
        print(path)
        print(imagePath)
        
     /*   let myURLString = "http://hire-people.com/host2/news_wp/faq/"
        guard let myURL = URL(string: myURLString) else {
            print("Error: \(myURLString) doesn't seem to be a valid URL")
            return
        }
        
        do {
            let myHTMLString = try String(contentsOf: myURL, encoding: .ascii)
            print("HTML : \(myHTMLString)")
            UserDefaults.standard.set(myHTMLString, forKey: "FAQHtml")
        } catch let error {
            print("Error: \(error)")
        }*/
        
        
        UserDefaults.standard.set("False", forKey: "CallWillDisplayCell")
        let menuIdStr = UserDefaults.standard.value(forKey: "MenuID") as? String ?? ""
        print(menuIdStr)
        for i in 0..<4{
            if i == 0{
               /* DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2, execute: {
                    let FaqurlStr = URL(string: "http://hire-people.com/host2/news_wp/faq/")
                    let request = URLRequest(url: FaqurlStr!)
                    URLCache.shared.cachedResponse(for: request)
                    self.webViewUrlLoad.loadRequest(request)
                })*/
            }else if i == 1{
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2, execute: {
                    let HowToUseurlStr = URL(string: "http://hire-people.com/host2/news_wp/how-use-app/")
                    let request1 = URLRequest(url: HowToUseurlStr!)
                    URLCache.shared.cachedResponse(for: request1)
                    self.webViewUrlLoad.loadRequest(request1)
                })
            }else if i == 2{
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2, execute: {
                    let Privacyurl = URL(string: "http://hire-people.com/host2/news_wp/privacy-policy/")
                    let request2 = URLRequest(url: Privacyurl!)
                    URLCache.shared.cachedResponse(for: request2)
                    self.webViewUrlLoad.loadRequest(request2)
                })
            }else if i == 3{
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2, execute: {
                    let contectUsurl = URL(string: "http://hire-people.com/host2/news_wp/contact-us/")
                    let request3 = URLRequest(url: contectUsurl!)
                    URLCache.shared.cachedResponse(for: request3)
                    self.webViewUrlLoad.loadRequest(request3)
                })
            }
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func saveImageToDocumentDirectory(image: UIImage ) {
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileName = "WhatsApp-Image-2019-01-24-at-11.04.29-AM.jpeg" // name of the image to be saved
        let fileURL = documentsDirectory.appendingPathComponent(fileName)
        if let data = UIImageJPEGRepresentation(image, 1.0),!FileManager.default.fileExists(atPath: fileURL.path){
            do {
                try data.write(to: fileURL)
                print("file saved")
            } catch {
                print("error saving file:", error)
            }
        }
    }
  
    
    
    func loadImageFromDocumentDirectory(nameOfImage : String) -> UIImage {
        let nsDocumentDirectory = FileManager.SearchPathDirectory.documentDirectory
        let nsUserDomainMask = FileManager.SearchPathDomainMask.userDomainMask
        let paths = NSSearchPathForDirectoriesInDomains(nsDocumentDirectory, nsUserDomainMask, true)
        if let dirPath = paths.first{
            let imageURL = URL(fileURLWithPath: dirPath).appendingPathComponent(nameOfImage)
            imagePath = "\(imageURL)"
            let image    = UIImage(contentsOfFile: imageURL.path)
            return image!
        }
        return UIImage.init(named: "default.png")!
    }
    func matches(for regex: String!, in text: String!) -> [String] {
        do {
            let regex = try NSRegularExpression(pattern: regex, options: [])
            let nsString = text as NSString
            let results = regex.matches(in: text, range: NSMakeRange(0, nsString.length))
            return results.map { nsString.substring(with: $0.range)}
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
            return []
        }
    }
    
    // MARK: - Button Action Method
    @IBAction func allIssuesButtonClicked(_ sender: Any) {
        if allIssuesButton.isSelected {
            
        }else{
            allIssuesButtonSelect()
            mainScrollView.scrollRectToVisible(CGRect(x: 0, y: 0, width: mainScrollView.frame.size.width, height: mainScrollView.frame.size.height), animated: true)
        }
    }
    @IBAction func downloadedButtonClicked(_ sender: Any) {
        if downloadedButton.isSelected{
            
        }else{
            downloadedButtonSelect()
            mainScrollView.scrollRectToVisible(CGRect(x: self.view.frame.size.width, y: 0, width: mainScrollView.frame.size.width, height: mainScrollView.frame.size.height), animated: true)
        }
    }
    @IBAction func settingButtonClicked(_ sender: Any) {
        let Setting = self.storyboard?.instantiateViewController(withIdentifier: "SettingVC") as! SettingVC
        self.navigationController?.pushViewController(Setting, animated: true)
    }
    
    //MARK: - Button Select Method
    func allIssuesButtonSelect(){
        allIssuesButton.isSelected = true
        downloadedButton.isSelected = false
        downloadedLineView.backgroundColor = UIColor.clear
        allIssuesLineView.backgroundColor = UIColor(red: 31.0/255, green: 68.0/255, blue: 161.0/255, alpha:1.0)
    }
    func downloadedButtonSelect(){
        allIssuesButton.isSelected = false
        downloadedButton.isSelected = true
        allIssuesLineView.backgroundColor = UIColor.clear
        downloadedLineView.backgroundColor = UIColor(red: 31.0/255, green: 68.0/255, blue: 161.0/255, alpha:1.0)
    }
    
    //MARK:- WebView Methods
    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        if let redirectURL = EVURLCache.shouldRedirect(request: request) {
            let r = URLRequest(url: redirectURL)
            webView.loadRequest(r)
            return false
        }
        return true
    }
}

extension HomeVC: UIScrollViewDelegate{
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if mainScrollView.bounds.origin.x == 0 {
            allIssuesButtonSelect()
            
        } else if mainScrollView.bounds.origin.x == self.view.frame.size.width {
            downloadedButtonSelect()
            
        }
    }
}
