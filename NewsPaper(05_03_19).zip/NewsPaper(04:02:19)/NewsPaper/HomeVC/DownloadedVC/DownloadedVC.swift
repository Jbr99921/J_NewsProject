//
//  DownloadedVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 05/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//  Created by archirayan on 4/12/18.
//  Author:www.archirayan.com
//  Email:info@archirayan.com
//
//

import UIKit

class DownloadedVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var sk_data: SKDatabase?
    
    var pdfIdStr: String = String()
    
    var dateArray: NSMutableArray = NSMutableArray()
    var newsPaperImageArray: NSMutableArray = NSMutableArray()
    
    @IBOutlet var downloadedTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        let reach = Reachability()
        if reach.isConnectedToNetwork() == true {
            GetDownloadedPdfData()
        }else{
            let userId = UserDefaults.standard.value(forKey: "UserId") as! String
            self.sk_data = SKDatabase(file: "NewsPaperDB.db")
            
            let GetDownloadedTbl = "SELECT * FROM DownloadedTbl where user_id='\(userId)'"
            
            let GetDownloadeddataArray1 = self.sk_data?.lookupAll(forSQL: GetDownloadedTbl)
            
            let GetDownloadedMutableArray2 = NSMutableArray(array: GetDownloadeddataArray1!)
            dateArray = GetDownloadedMutableArray2.mutableCopy() as! NSMutableArray
            self.downloadedTableView.reloadData()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        let reach = Reachability()
        if reach.isConnectedToNetwork() == false {
            let userId = UserDefaults.standard.value(forKey: "UserId") as! String
            self.sk_data = SKDatabase(file: "NewsPaperDB.db")
            
            let GetDownloadedTbl = "SELECT * FROM DownloadedTbl where user_id='\(userId)'"
            
            let GetDownloadeddataArray1 = self.sk_data?.lookupAll(forSQL: GetDownloadedTbl)
            
            let GetDownloadedMutableArray2 = NSMutableArray(array: GetDownloadeddataArray1!)
            dateArray = GetDownloadedMutableArray2.mutableCopy() as! NSMutableArray
            self.downloadedTableView.reloadData()
        }
    }

    
    //MARK: - TableView Deleget Method
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (dateArray .value(forKey: "id") as AnyObject).count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:DownloadedTableViewCell = tableView.dequeueReusableCell(withIdentifier: "DownloadedTableViewCell") as! DownloadedTableViewCell
        
        cell.dateLabel.text = (dateArray[indexPath.row] as AnyObject) .value(forKey: "date") as? String
        let reach = Reachability()
        if reach.isConnectedToNetwork() == true {
            let imageUrl = (dateArray[indexPath.row] as AnyObject) .value(forKey: "image_url") as! String
            
            let str = imageUrl.replacingOccurrences(of: " ", with: "")

            if let data = NSData(contentsOf: NSURL(string:str as String )! as URL) {
                cell.newsImageView.image = UIImage(data: data as Data)
            }else{
                cell.newsImageView.image = #imageLiteral(resourceName: "ic_splash_newspaper")
            }
        }else{
            let imageUrl = (dateArray[indexPath.row] as AnyObject) .value(forKey: "image_url") as! String
            if let decodedData = Data(base64Encoded: imageUrl, options: .ignoreUnknownCharacters) {
                cell.newsImageView.image = UIImage(data: decodedData)
            }else{
                cell.newsImageView.image = #imageLiteral(resourceName: "ic_splash_newspaper")
            }
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        UserDefaults.standard.set("false", forKey: "IsComeFromMenu")
        UserDefaults.standard.set("0", forKey: "indexPath")
        let reach = Reachability()
        if reach.isConnectedToNetwork() == true {
            //let pdfIdNumber = (dateArray[indexPath.row] as AnyObject) .value(forKey: "id") as! NSNumber
            pdfIdStr = "\((dateArray[indexPath.row] as AnyObject) .value(forKey: "id") as! NSNumber)"//"\(pdfIdNumber)"
        }else{
            pdfIdStr = (dateArray[indexPath.row] as AnyObject) .value(forKey: "id") as! String
        }
        let HTMLViewer = self.storyboard?.instantiateViewController(withIdentifier: "HTMLViewerVC") as! HTMLViewerVC
        HTMLViewer.pdfIdStr = pdfIdStr
        self.navigationController?.pushViewController(HTMLViewer, animated: true)
    }
    
    
    
    //MARK: - Get Downloaded Pdf
    func GetDownloadedPdfData(){
        
        ACProgressHUD.shared.showHUD()
        
        DispatchQueue.global(qos: .background).async {
            //http://hire-people.com/host2/News/apis/mainpages2.php?user_id=17&action=dwd
            //http://hire-people.com/host2/news_wp/api/downloaded.php?user_id=21&page_id=34
            
            let myUrl = URL(string: GlobalUrl.BaseUrl + "mainpages2.php?");
            print(myUrl!)
            var request = URLRequest(url:myUrl!)
            request.httpMethod = "POST"
            let userId = UserDefaults.standard.value(forKeyPath: "UserId") as! String 
            print(userId)
            var postString: String = String()
            postString = "user_id=" + userId + "&action=dwd"
            print(postString)
            
            let userName = "admin"
            let password = "admin"
            var _: Error? = nil
            let authStr = "\(userName):\(password)"
            let authData: Data? = authStr.data(using: .ascii)
            let authStrData = String(data: authData?.base64EncodedData(options: .endLineWithLineFeed) ?? Data(), encoding: .ascii)
            let authValue = "Basic \(authStrData!)"
            request.addValue(authValue, forHTTPHeaderField: "Authorization")
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                
                if error != nil
                {
                    ACProgressHUD.shared.hideHUD()
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error!)
                    
                    return
                }
                
                print("response = \(response!)")
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    DispatchQueue.main.async {
                        
                        if let parseJSON = json {
                            
                            print(parseJSON)
                            let status =   parseJSON["status"] as! String
                            
                            if status == "true"{
                                ACProgressHUD.shared.hideHUD()
                                let dataDic = parseJSON["data"] as AnyObject
                                self.dateArray = dataDic as! NSMutableArray
                                
                                var imageBase64Str: String = String()
                                var idStr: String = String()
                                var titleStr: String = String()
                                var postDateStr: String = String()
                                var authorStr: String = String()
                                
                                for i in 0..<self.dateArray.count{
                                    
                                    let imageUrl = (self.dateArray[i] as AnyObject) .value(forKey: "image_url") as? String ?? ""
                                    print(imageUrl)
                                    let str = imageUrl.replacingOccurrences(of: " ", with: " ")
                                    print(str)
                                    
                                    if let data = NSData(contentsOf: NSURL(string:str as String )! as URL) {
                                        imageBase64Str = data.base64EncodedString(options: .lineLength64Characters)
                                       
                                    }
                                    
                                    let id = (self.dateArray[i] as AnyObject) .value(forKey: "id") as! NSNumber
                                    idStr = "\(id)"
                                    titleStr = (self.dateArray[i] as AnyObject) .value(forKey: "title") as? String ?? ""
                                    postDateStr = (self.dateArray[i] as AnyObject) .value(forKey: "post_date") as? String ?? ""
                                    authorStr = (self.dateArray[i] as AnyObject) .value(forKey: "author") as? String ?? ""
                                    
                                    
                                    self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                    
                                    let Premimum = "SELECT * FROM DownloadedTbl where id='\(idStr)' and user_id='\(userId)'"
                                    
                                    let dataArray1 = self.sk_data?.lookupAll(forSQL: Premimum)
                                    
                                    let nsMutableArray5 = NSMutableArray(array: dataArray1!)
                                    
                                    let array = nsMutableArray5 .mutableCopy() as! NSMutableArray
                                    if array.count == 0{
                                        self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                        let InsertdownloadedTbl = "insert into DownloadedTbl (id,title,image_url,post_date,author,user_id) VALUES ('\(idStr)','\(titleStr)','\(imageBase64Str)','\(postDateStr)','\(authorStr)','\(userId)')"
                                        let st1: Bool =  ((self.sk_data?.performSQL(InsertdownloadedTbl)) != nil)
                                        if st1 {
                                            print("Data Insert")
                                        }
                                        else {
                                            print("Data Not Insert")
                                        }
                                        
                                    }else{
                                        self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                        let UpdateDownloadedTbl = "UPDATE DownloadedTbl SET title='\(titleStr)',image_url='\(imageBase64Str)',post_date='\(postDateStr)',author='\(authorStr)' WHERE id='\(idStr)' and user_id='\(userId)'"
                                       
                                        self.sk_data?.performSQL(UpdateDownloadedTbl)
                                        
                                    }
                                    
                                }
                                
                                if self.dateArray.count == 0{
                                    let alert = UIAlertController(title: "Alert", message:"News Not Found", preferredStyle:     UIAlertControllerStyle.alert)
                                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                self.downloadedTableView.reloadData()
                                
                            }else{
                                ACProgressHUD.shared.hideHUD()
                                let alert = UIAlertController(title: "ERROR", message:"News Not Found", preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                                
                            }
                        }
                    }
                }
                catch {
                    ACProgressHUD.shared.hideHUD()
                    
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error)
                }
            }
            task.resume()
        }
    }
}
