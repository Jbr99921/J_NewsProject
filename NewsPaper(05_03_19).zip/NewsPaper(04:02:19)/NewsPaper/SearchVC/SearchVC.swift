//
//  SearchVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 06/02/19.
//  Copyright © 2019 Archirayan. All rights reserved.
//

import UIKit

class SearchVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var index: String = String()
    
    var tempSearchArray: NSMutableArray = NSMutableArray()
    var searchArray: NSMutableArray = NSMutableArray()
    var listArray: NSMutableArray = NSMutableArray()
    
    
    
    var sk_data: SKDatabase?
    
    var getSectionArray: NSMutableArray = NSMutableArray()
    var sectionArray: NSMutableArray = NSMutableArray()

    @IBOutlet var searchTextField: UITextField!
    var pdfIdStr: String = String()
    @IBOutlet var searchListTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        pdfIdStr = UserDefaults.standard.value(forKey: "PdfIdForSearch") as? String ?? ""
        self.sk_data = SKDatabase(file: "NewsPaperDB.db")
        
        let GetDownloadedTbl = "SELECT * FROM MenuTbl where news_id='\(pdfIdStr)'"
        
        let GetDownloadeddataArray1 = self.sk_data?.lookupAll(forSQL: GetDownloadedTbl)
        
        print(GetDownloadeddataArray1!)
        
        let GetDownloadedMutableArray2 = NSMutableArray(array: GetDownloadeddataArray1!)
        getSectionArray = GetDownloadedMutableArray2.mutableCopy() as! NSMutableArray
        sectionArray = GetDownloadedMutableArray2.mutableCopy() as! NSMutableArray
        tempSearchArray = GetDownloadedMutableArray2.mutableCopy() as! NSMutableArray
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // MARK: - TextField Deleget Method
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //delegate method
        searchTextField.resignFirstResponder()
        return true
    }
    
    //MARK:- Search
    @IBAction func searchTextField(_ sender: Any) {
         if (searchTextField.text?.isEmpty)!{
            listArray.removeAllObjects()
            searchListTableView.reloadData()
         }else{
            let namePredicate = NSPredicate(format: "title CONTAINS[c] %@", searchTextField.text!)
            let term = self.tempSearchArray.filtered(using: namePredicate)
            print(term)
            searchArray.addObjects(from: term)
            print(searchArray)
            listArray = searchArray .mutableCopy() as! NSMutableArray
            searchArray.removeAllObjects()
            searchListTableView.reloadData()
        }
    }
    // MARK: - TableView Deleget Method
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return (listArray .value(forKey: "id") as AnyObject).count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let mycell:SearchListTVC = tableView.dequeueReusableCell(withIdentifier: "SearchListTVC") as! SearchListTVC
        mycell.sectioNameLabel.text = (listArray[indexPath.row] as AnyObject) .value(forKey: "title") as? String
        
         return mycell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let idStr = (listArray[indexPath.row] as AnyObject) .value(forKey: "id") as! String
        for i in 0..<getSectionArray.count{
            if (getSectionArray[i] as AnyObject) .value(forKey: "id") as! String == idStr{
                index = "\(i)"
                UserDefaults.standard.set("True", forKey: "IsComeFromMenu")
                UserDefaults.standard.set(index, forKey: "indexPath")
                UserDefaults.standard.set("True", forKey: "CallWillDisplayCell")
                _ = self.navigationController?.popViewController(animated: true)
                
            }
        }
    }
    
     // MARK: - Button Action Method
     @IBAction func backButtonClicked(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
     }

}
