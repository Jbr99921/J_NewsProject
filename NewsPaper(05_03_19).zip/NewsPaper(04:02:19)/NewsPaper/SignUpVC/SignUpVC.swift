//
//  SignUpVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 04/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//  Created by archirayan on 4/12/18.
//  Author:www.archirayan.com
//  Email:info@archirayan.com
//

import UIKit

class SignUpVC: UIViewController {
    
    @IBOutlet var signUpBtn: UIButton!
    @IBOutlet var hideShowPasswordBtn: UIButton!
    @IBOutlet var confirmPaswordHideShowBtn: UIButton!
    @IBOutlet var fullNameTxt: UITextField!
    @IBOutlet var emailtxt: UITextField!
    @IBOutlet var passwordTxt: UITextField!
    @IBOutlet var confirmPasswordTxt: VCTextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        signUpBtn.layer.cornerRadius = 5
        hideShowPasswordBtn.isSelected = true
        passwordTxt.isSecureTextEntry = true
        confirmPaswordHideShowBtn.isSelected = true
        confirmPasswordTxt.isSecureTextEntry = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Button Action Method
    @IBAction func backButtonClicked(_ sender: UIButton){
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func passwordHideandShowButtonClicked(_ sender: UIButton){
        if hideShowPasswordBtn.isSelected == true{
            hideShowPasswordBtn.setBackgroundImage(#imageLiteral(resourceName: "ic_hide_psw_off"), for: .normal)
            passwordTxt.isSecureTextEntry = false
            hideShowPasswordBtn.isSelected = false
        }else{
            hideShowPasswordBtn.setBackgroundImage(#imageLiteral(resourceName: "view"), for: .normal)
            passwordTxt.isSecureTextEntry = true
            hideShowPasswordBtn.isSelected = true
        }
    }
    @IBAction func confirmPaswordHideShowBtn(_ sender: Any) {
        if confirmPaswordHideShowBtn.isSelected == true{
            confirmPaswordHideShowBtn.setBackgroundImage(#imageLiteral(resourceName: "ic_hide_psw_off"), for: .normal)
            confirmPasswordTxt.isSecureTextEntry = false
            confirmPaswordHideShowBtn.isSelected = false
        }else{
            confirmPaswordHideShowBtn.setBackgroundImage(#imageLiteral(resourceName: "view"), for: .normal)
            confirmPasswordTxt.isSecureTextEntry = true
            confirmPaswordHideShowBtn.isSelected = true
        }
    }
    
    @IBAction func SignUpButtonClicked(_ sender: UIButton){
        AddUser()
    }
    
    func AddUser(){
        
        ACProgressHUD.shared.showHUD()
        
        DispatchQueue.global(qos: .background).async {
            
            //http://hire-people.com/host2/news_wp/api/registration.php?user_login=archirayan6&user_pass=12345&user_email=archirayan6@gmail.com
            
            let myUrl = URL(string: GlobalUrl.BaseUrl + "registration.php?");
            print(myUrl!)
            var request = URLRequest(url:myUrl!)
            request.httpMethod = "POST"
            
            let postString = "user_login=" + self.fullNameTxt.text! + "&user_pass=" + self.passwordTxt.text! +  "&user_email=" + self.emailtxt.text!
            print(postString)
            
            let userName = "admin"
            let password = "admin"
            var _: Error? = nil
            let authStr = "\(userName):\(password)"
            let authData: Data? = authStr.data(using: .ascii)
            let authStrData = String(data: authData?.base64EncodedData(options: .endLineWithLineFeed) ?? Data(), encoding: .ascii)
            let authValue = "Basic \(authStrData!)"
            request.addValue(authValue, forHTTPHeaderField: "Authorization")
            
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                
                if error != nil
                {
                    ACProgressHUD.shared.hideHUD()
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error!)
                    
                    return
                }
                
                print("response = \(response!)")
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    DispatchQueue.main.async {
                        
                        if let parseJSON = json {
                            
                            print(parseJSON)
                            let status =   parseJSON["status"] as! String
                            
                            if status == "true"{
                                ACProgressHUD.shared.hideHUD()
                                let SignIN = self.storyboard?.instantiateViewController(withIdentifier: "SignINVC") as! SignINVC
                                SignIN.isComeFrom = "SignUP"
                                self.navigationController?.pushViewController(SignIN, animated: true)
                            }else{
                                ACProgressHUD.shared.hideHUD()
                                let alert = UIAlertController(title: "Alert", message:"Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                            }
                        }
                    }
                }
                catch {
                    ACProgressHUD.shared.hideHUD()
                    
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error)
                }
            }
            task.resume()
        }
    }
}
