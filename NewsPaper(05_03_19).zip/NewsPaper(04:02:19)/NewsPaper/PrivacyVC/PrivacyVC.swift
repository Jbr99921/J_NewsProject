//
//  PrivacyVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 06/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//

import UIKit
import EVURLCache

class PrivacyVC: UIViewController, UIWebViewDelegate{

    @IBOutlet var privacyWebView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        privacyWebView.delegate = self
        privacyWebView.scrollView.bounces = false
        let url = URL(string: "http://hire-people.com/host2/news_wp/privacy-policy/")
        privacyWebView.loadRequest(URLRequest(url: url!))
        ACProgressHUD.shared.showHUD()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func webViewDidStartLoad(_ webView: UIWebView) {
    
    }
    func webViewDidFinishLoad(_ webView: UIWebView)
    {
        ACProgressHUD.shared.hideHUD()
    }
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        ACProgressHUD.shared.hideHUD()
    }
    //MARK:- WebView Methods
    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        if let redirectURL = EVURLCache.shouldRedirect(request: request) {
            let r = URLRequest(url: redirectURL)
            webView.loadRequest(r)
            return false
        }
        return true
    }

 
    // MARK: - Button Action Method
    @IBAction func backButtonClicked(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
}
