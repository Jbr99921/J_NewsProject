//
//  WishlistVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 06/02/19.
//  Copyright © 2019 Archirayan. All rights reserved.
//

import UIKit

class WishlistVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var PDFId: String = String()
    var PDFName: String = String()
    var PdfImageUrl: String = String()
    var authoreStr: String = String()
    var postDateStr: String = String()
    var statusStr: String = String()
    
    var dataArray: NSMutableArray = NSMutableArray()
    
     var sk_data: SKDatabase?
    
    var pdfIdStr: String = String()

    @IBOutlet var wishlistTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let userId = UserDefaults.standard.value(forKey: "UserId") as! String
        self.sk_data = SKDatabase(file: "NewsPaperDB.db")
        
        let GetAllIssue = "SELECT * FROM wishlistTbl where user_id='\(userId)'"
        
        let GetAllIssuedataArray1 = self.sk_data?.lookupAll(forSQL: GetAllIssue)
        
        let GetAllIssuensMutableArray2 = NSMutableArray(array: GetAllIssuedataArray1!)
        dataArray = GetAllIssuensMutableArray2.mutableCopy() as! NSMutableArray
        self.wishlistTableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - TableView Deleget Method
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (dataArray .value(forKey: "id") as AnyObject).count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:WishlistTVC = tableView.dequeueReusableCell(withIdentifier: "WishlistTVC") as! WishlistTVC
        
        cell.getButton.tag = indexPath.row
        let status = (dataArray[indexPath.row] as AnyObject).value(forKey: "status") as! String
        print(status)
        
        if status == "\(0)"{
            cell.getButton.setTitle("GET", for: .normal)
            cell.getButton.addTarget(self, action:  #selector(GetButtonClicked(sender:)), for: .touchUpInside)
        }else{
            cell.getButton.setTitle("OPEN", for: .normal)
            cell.getButton.addTarget(self, action:  #selector(OpenButtonClicked(sender:)), for: .touchUpInside)
        }
        
        cell.dateLabel.text = (dataArray[indexPath.row] as AnyObject) .value(forKey: "post_date") as? String
        
        
        let imageUrl = (dataArray[indexPath.row] as AnyObject) .value(forKey: "image_url") as? String ?? ""
        if let decodedData = Data(base64Encoded: imageUrl, options: .ignoreUnknownCharacters) {
            cell.newsImageView.image = UIImage(data: decodedData)
        }else{
            cell.newsImageView.image = #imageLiteral(resourceName: "ic_splash_newspaper")
        }
        
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let status = (dataArray[indexPath.row] as AnyObject) .value(forKey: "status") as! String
        if status == "\(0)"{
            PDFName = (dataArray[indexPath.row] as AnyObject) .value(forKey: "title") as! String
            PdfImageUrl = (dataArray[indexPath.row] as AnyObject) .value(forKey: "image_url") as! String
            authoreStr = (dataArray[indexPath.row] as AnyObject) .value(forKey: "author") as! String
            postDateStr = (dataArray[indexPath.row] as AnyObject) .value(forKey: "post_date") as! String
            statusStr = (dataArray[indexPath.row] as AnyObject) .value(forKey: "status") as! String
            
            PDFId = (dataArray[indexPath.row] as AnyObject) .value(forKey: "id") as! String
            
            GetPDF()
        }else{
            PDFId = (dataArray[indexPath.row] as AnyObject) .value(forKey: "id") as! String
            
            OpenPDF()
        }
        
    }
    
    //MARK: Open And Get Pdf
    func GetPDF(){
        // ACProgressHUD.shared.showHUD()
        let downloadingAndGet = self.storyboard?.instantiateViewController(withIdentifier: "DownloadingAndGetVC") as! DownloadingAndGetVC
        downloadingAndGet.pdfName = PDFName
        downloadingAndGet.PDFId = PDFId
        downloadingAndGet.pdfImageUrl = PdfImageUrl
        downloadingAndGet.authoreStr = authoreStr
        downloadingAndGet.postDateStr = postDateStr
        downloadingAndGet.statusStr = statusStr
        self.navigationController?.pushViewController(downloadingAndGet, animated: true)
        // savePdf(urlString: pdfUrlStr, fileName: PDFName)
    }
    func OpenPDF(){
        UserDefaults.standard.set("false", forKey: "IsComeFromMenu")
        UserDefaults.standard.set("True", forKey: "FisrtTime")
        let HTMLViewer = self.storyboard?.instantiateViewController(withIdentifier: "HTMLViewerVC") as! HTMLViewerVC
        HTMLViewer.pdfIdStr = PDFId
        self.navigationController?.pushViewController(HTMLViewer, animated: true)
    }
    
    // MARK: - Button Action Method
    @IBAction func backButtonClicked(_ sender: Any) {
         _ = self.navigationController?.popViewController(animated: true)
    }
    @objc func GetButtonClicked(sender: UIButton){
        PDFName = (dataArray[sender.tag] as AnyObject) .value(forKey: "title") as! String
        PdfImageUrl = (dataArray[sender.tag] as AnyObject) .value(forKey: "image") as! String
        authoreStr = (dataArray[sender.tag] as AnyObject) .value(forKey: "author") as! String
        postDateStr = (dataArray[sender.tag] as AnyObject) .value(forKey: "post_date") as! String
        statusStr = (dataArray[sender.tag] as AnyObject) .value(forKey: "status") as! String
        
        PDFId = (dataArray[sender.tag] as AnyObject) .value(forKey: "id") as! String
        
        GetPDF()
    }
    
    @objc func OpenButtonClicked(sender: UIButton){
        
        PDFId = (dataArray[sender.tag] as AnyObject) .value(forKey: "id") as! String
        
        OpenPDF()
    }
    

}
