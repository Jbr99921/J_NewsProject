//
//  WishlistTVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 06/02/19.
//  Copyright © 2019 Archirayan. All rights reserved.
//

import UIKit

class WishlistTVC: UITableViewCell {
    
    @IBOutlet var getButton: UIButton!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var newsImageView: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
