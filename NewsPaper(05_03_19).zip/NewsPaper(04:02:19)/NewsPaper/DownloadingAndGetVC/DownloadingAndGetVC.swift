//
//  DownloadingAndGetVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 07/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//

import UIKit

class DownloadingAndGetVC: UIViewController {
    
    var sk_data: SKDatabase?
    
    var mainPdfNameStr: String = String()
    
    let pdfBaseUrl = "http://hire-people.com/host2/news_wp/api/users_pdf/"
    
    var getSectionArray: NSMutableArray = NSMutableArray()
    
    var index: Int = Int()
    var pdfName: String = String()
    var PDFId: String = String()
    var PDFUrl: String = String()
    var pdfImageUrl: String = String()
    var authoreStr: String = String()
    var postDateStr: String = String()
    var statusStr: String = String()
    
    @IBOutlet var cancleButtonHolderView: UIView!
    @IBOutlet var moreButtonholderView: UIView!
    @IBOutlet var getButton: UIButton!
    @IBOutlet var getView: UIView!
    @IBOutlet var downloadindAndCancelView: UIView!
    @IBOutlet var sizeLabel: UILabel!
    @IBOutlet var newsImageView: UIImageView!
    @IBOutlet var datelabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        cancleButtonHolderView.layer.borderColor = UIColor.black.cgColor
        cancleButtonHolderView.layer.borderWidth = 1
        
        
        let reach = Reachability()
        if reach.isConnectedToNetwork() == true {
            getView.isHidden = true
            downloadindAndCancelView.isHidden = false
            let str = pdfImageUrl.replacingOccurrences(of: " ", with: "")
            print(str)
            
        
            if let data = NSData(contentsOf: NSURL(string:str as String )! as URL) {
                newsImageView.image = UIImage(data: data as Data)
            }else{
                newsImageView.image = #imageLiteral(resourceName: "ic_splash_newspaper")
            }
            if let data = NSData(contentsOf: NSURL(string:str as String )! as URL) {
                pdfImageUrl = data.base64EncodedString(options: .lineLength64Characters)
                
            }
            
            DowmloadPDF()
        }else{
            getView.isHidden = false
            downloadindAndCancelView.isHidden = true
            if let decodedData = Data(base64Encoded: pdfImageUrl, options: .ignoreUnknownCharacters) {
                newsImageView.image = UIImage(data: decodedData)
            }else{
                newsImageView.image = #imageLiteral(resourceName: "ic_splash_newspaper")
            }
        }
        moreButtonholderView.isHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //MARK: - Touch Method
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        if touch?.view == self.view {
            moreButtonholderView.fadeOut()
        }
    }
    
    // MARK: - Button Action Method
    @IBAction func homeButtonClicked(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    @IBAction func moreButtonClicked(_ sender: Any) {
        moreButtonholderView.fadeIn()
    }
    @IBAction func downloadingButtonClicked(_ sender: Any) {
    }
    @IBAction func cancelButtonClicked(_ sender: Any) {
        downloadindAndCancelView.isHidden = true
        getView.isHidden = false
    }
    @IBAction func getButtonClicked(_ sender: Any) {
        let reach = Reachability()
        if reach.isConnectedToNetwork() == true {
            DowmloadPDF()
        }else{
            let alert = UIAlertController(title: "Alert", message: "No Internet Connection", preferredStyle:     UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    @IBAction func promotionsButtonClicked(_ sender: Any) {
        moreButtonholderView.fadeOut()
    }
    @IBAction func wishlistButtonClicked(_ sender: Any) {
            let userId = UserDefaults.standard.value(forKey: "UserId") as! String
            self.sk_data = SKDatabase(file: "NewsPaperDB.db")
        
            let Premimum = "SELECT * FROM wishlistTbl where id='\(PDFId)' and user_id='\(userId)'"
        
            let dataArray1 = self.sk_data?.lookupAll(forSQL: Premimum)
        
            let nsMutableArray5 = NSMutableArray(array: dataArray1!)
        
            let array = nsMutableArray5 .mutableCopy() as! NSMutableArray
            if array.count == 0{
                self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                let InsertAllIssue = "insert into wishlistTbl (id,title,image_url,post_date,status,user_id,author) VALUES ('\(PDFId)','\(pdfName)','\(pdfImageUrl)','\(postDateStr)','\(statusStr)','\(userId)','\(authoreStr)')"
                let st1: Bool =  ((self.sk_data?.performSQL(InsertAllIssue)) != nil)
                if st1 {
                    print("Data Insert")
                }
                else {
                    print("Data Not Insert")
                }
                
            }else{
                self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                let updateAllIssue = "UPDATE AllIssue SET title='\(pdfName)',image_url='\(pdfImageUrl)',post_date='\(postDateStr)',status='\(statusStr)',author='\(authoreStr)' WHERE id='\(PDFId)' and user_id='\(userId)'"
                print(updateAllIssue)
                self.sk_data?.performSQL(updateAllIssue)
                
            }
        
        moreButtonholderView.fadeOut()
        
        let alert = UIAlertController(title: "Alert", message: "Added To Wishlist", preferredStyle:     UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    //MARK: - Dowmload PDF
    func DowmloadPDF(){
        
        ACProgressHUD.shared.showHUD()
        
        DispatchQueue.global(qos: .background).async {
            //http://hire-people.com/host2/news_wp/api/downloaded.php?user_id=21&page_id=34
            
            let myUrl = URL(string: GlobalUrl.BaseUrl + "downloaded.php?");
            var request = URLRequest(url:myUrl!)
            request.httpMethod = "POST"
            let userId = UserDefaults.standard.value(forKey: "UserId") as! String
            
            let postString = "user_id=" + userId + "&page_id=" + self.PDFId
            print(postString)
            let userName = "admin"
            let password = "admin"
            var _: Error? = nil
            let authStr = "\(userName):\(password)"
            let authData: Data? = authStr.data(using: .ascii)
            let authStrData = String(data: authData?.base64EncodedData(options: .endLineWithLineFeed) ?? Data(), encoding: .ascii)
            let authValue = "Basic \(authStrData!)"
            request.addValue(authValue, forHTTPHeaderField: "Authorization")
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                
                if error != nil
                {
                    ACProgressHUD.shared.hideHUD()
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error!)
                    
                    return
                }
                
                print("response = \(response!)")
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    DispatchQueue.main.async {
                        
                        if let parseJSON = json {
                            
                            print(parseJSON)
                            let status =   parseJSON["status"] as! String
                            
                            if status == "true"{
                                ACProgressHUD.shared.hideHUD()

                                self.GetSection()
                            }else{
                                ACProgressHUD.shared.hideHUD()
                                let alert = UIAlertController(title: "ERROR", message:"Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                                
                            }
                        }
                    }
                }
                catch {
                    ACProgressHUD.shared.hideHUD()
                    
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error)
                }
            }
            task.resume()
        }
    }
    
    //MARK: - Get Section PDF
    func GetSection(){
        
        ACProgressHUD.shared.showHUD()
        
        DispatchQueue.global(qos: .background).async {
            //
            
            
            let myUrl = URL(string: GlobalUrl.BaseUrl + "subpages.php?");
            var request = URLRequest(url:myUrl!)
            request.httpMethod = "POST"
            let userId = UserDefaults.standard.value(forKey: "UserId") as! String
            
            let postString = "news_id=" + self.PDFId
            print(postString)
            let userName = "admin"
            let password = "admin"
            var _: Error? = nil
            let authStr = "\(userName):\(password)"
            let authData: Data? = authStr.data(using: .ascii)
            let authStrData = String(data: authData?.base64EncodedData(options: .endLineWithLineFeed) ?? Data(), encoding: .ascii)
            let authValue = "Basic \(authStrData!)"
            request.addValue(authValue, forHTTPHeaderField: "Authorization")
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                
                if error != nil
                {
                    ACProgressHUD.shared.hideHUD()
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error!)
                    
                    return
                }
                
                print("response = \(response!)")
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    DispatchQueue.main.async {
                        
                        if let parseJSON = json {
                            
                            print(parseJSON)
                            let status =   parseJSON["status"] as! String
                            
                            if status == "true"{
                                ACProgressHUD.shared.hideHUD()
                                let dataDic = parseJSON["data"] as AnyObject
                                self.getSectionArray = dataDic as! NSMutableArray
                                
                                var idStr: String = String()
                                var titleStr: String = String()
                                var post_url: String = String()
                                var myHTMLString: String = String()
                                var HtmlBase64: String = String()
                                for i in 0..<self.getSectionArray.count{
                                    let id = (self.getSectionArray[i] as AnyObject) .value(forKey: "id") as! NSNumber
                                    idStr = "\(id)"
                                    titleStr = (self.getSectionArray[i] as AnyObject) .value(forKey: "title") as? String ?? ""
                                    post_url = (self.getSectionArray[i] as AnyObject) .value(forKey: "post_url") as? String ?? ""
                                    
                                   myHTMLString = (self.getSectionArray[i] as AnyObject) .value(forKey: "post_html") as? String ?? ""
                                   HtmlBase64 = myHTMLString.toBase64()
                                    
                                    self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                    
                                    let Premimum = "SELECT * FROM MenuTbl where id='\(idStr)' and news_id='\(self.PDFId)'"
                                    
                                    let dataArray1 = self.sk_data?.lookupAll(forSQL: Premimum)

                                    let nsMutableArray5 = NSMutableArray(array: dataArray1!)
                                    
                                    let array = nsMutableArray5 .mutableCopy() as! NSMutableArray
                                    if array.count == 0{
                                        self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                        let InsertAllIssue = "insert into MenuTbl (id,title,post_url,news_id,HtmlWebView) VALUES ('\(idStr)','\(titleStr)','\(post_url)','\(self.PDFId)','\(HtmlBase64)')"
                                        let st1: Bool =  ((self.sk_data?.performSQL(InsertAllIssue)) != nil)
                                        if st1 {
                                            print("Data Insert")
                                        }
                                        else {
                                            print("Data Not Insert")
                                        }
                                        
                                    }else{
                                        self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                        let updateAllIssue = "UPDATE MenuTbl SET title='\(titleStr)',post_url='\(post_url)',HtmlWebView='\(HtmlBase64)' WHERE id='\(idStr)' and news_id='\(self.PDFId)'"
                                        print(updateAllIssue)
                                        self.sk_data?.performSQL(updateAllIssue)
                                        
                                    }
                                }
                                self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                
                                let Premimum = "SELECT * FROM wishlistTbl where id='\(self.PDFId)' and user_id='\(userId)'"
                                
                                let dataArray1 = self.sk_data?.lookupAll(forSQL: Premimum)
                                
                                let nsMutableArray5 = NSMutableArray(array: dataArray1!)
                                
                                let array = nsMutableArray5 .mutableCopy() as! NSMutableArray
                                if array.count == 0{
                                }else{
                                    self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                    let updateAllIssue = "UPDATE AllIssue SET title='\(self.pdfName)',image_url='\(self.pdfImageUrl)',post_date='\(self.postDateStr)',status='\(self.statusStr)',author='\(self.authoreStr)' WHERE id='\(self.PDFId)' and user_id='\(userId)'"
                                    print(updateAllIssue)
                                    self.sk_data?.performSQL(updateAllIssue)
                                }
                                
                                let news = "news"
                                for i in 0..<self.getSectionArray.count{
                                    let pageId = (self.getSectionArray[i] as AnyObject) .value(forKey: "id") as! NSNumber
                                    let combine = news + "\(pageId)"
                                    print(combine)
                                    let createPdfUrlStr = self.pdfBaseUrl + combine + "-" + self.PDFId + ".pdf"
                                    print(createPdfUrlStr)
                                    let pdfNameStr = combine + "-" + self.PDFId + ".pdf"
                                    print(pdfNameStr)
                                    self.mainPdfNameStr = pdfNameStr
                                    let urlString = createPdfUrlStr.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)
                                    self.savePdf(urlString: urlString!, fileName: self.mainPdfNameStr)
                                }
                                self.statusStr = "1"
                                let Home = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
                                self.navigationController?.pushViewController(Home, animated: true)
                            }else{
                                ACProgressHUD.shared.hideHUD()
                                let alert = UIAlertController(title: "ERROR", message:"Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                                
                            }
                        }
                    }
                }
                catch {
                    ACProgressHUD.shared.hideHUD()
                    
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error)
                }
            }
            task.resume()
        }
    }
    
    //MARK: - Downloding
    func savePdf(urlString:String, fileName:String) {
        DispatchQueue.main.async {
            let url = URL(string: urlString)
            let pdfData = try? Data.init(contentsOf: url!)
            let resourceDocPath = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last! as URL
            let pdfNameFromUrl = fileName
            let actualPath = resourceDocPath.appendingPathComponent(pdfNameFromUrl)
            do {
                try pdfData?.write(to: actualPath, options: .atomic)
                ACProgressHUD.shared.hideHUD()
                print("pdf successfully saved!")
                self.downloadindAndCancelView.isHidden = true
                self.getView.isHidden = false
            } catch {
                print("Pdf could not be saved")
                ACProgressHUD.shared.hideHUD()
                let alert = UIAlertController(title: "", message: "Pdf could not be saved", preferredStyle:     UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }


}

//MARK: - UIView Animation
extension UIView {
    
    func fadeIn(duration: TimeInterval = 0.5, delay: TimeInterval = 0.0, completion: @escaping ((Bool) -> Void) = {(finished: Bool) -> Void in }) {
        self.alpha = 0.0
        
        UIView.animate(withDuration: duration, delay: delay, options: UIViewAnimationOptions.curveEaseIn, animations: {
            self.isHidden = false
            self.alpha = 1.0
        }, completion: completion)
    }
    
    func fadeOut(duration: TimeInterval = 0.5, delay: TimeInterval = 0.0, completion: @escaping (Bool) -> Void = {(finished: Bool) -> Void in }) {
        self.alpha = 1.0
        
        UIView.animate(withDuration: duration, delay: delay, options: UIViewAnimationOptions.curveEaseIn, animations: {
            self.alpha = 0.0
        }) { (completed) in
            self.isHidden = true
            completion(true)
        }
    }
    
    func rightToleft(duration: TimeInterval = 0.5, delay: TimeInterval = 0.0, completion: @escaping (Bool) -> Void = {(finished: Bool) -> Void in }) {
        self.alpha = 1.0
        
        UIView.animate(withDuration: duration, delay: delay, options: UIViewAnimationOptions.transitionFlipFromRight, animations: {
            self.alpha = 0.0
        }) { (completed) in
            self.isHidden = true
            completion(true)
        }
    }
}


