//
//  HTMLViewerVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 21/01/19.
//  Copyright © 2019 Archirayan. All rights reserved.
//

import UIKit
import EVURLCache
import JavaScriptCore

class HTMLViewerVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UIWebViewDelegate  {
    
    var fontSize: CGFloat = CGFloat()
    var count = 0
    
    var cssString: String = String()
    
    @IBOutlet var newsImageView: UIImageView!
    @IBOutlet var newsImageHolderView: UIView!
    @IBOutlet var loadingActivity: UIActivityIndicatorView!
    @IBOutlet var loadingHolderView: UIView!
    @IBOutlet var menuButtonHolderView: UIView!
    @IBOutlet var menuHolderView: UIView!
    var sk_data: SKDatabase?
    
    var pdfIdStr: String = String()
    
    var getSectionArray: NSMutableArray = NSMutableArray()
    
    
    let urlArray = ["http://hire-people.com/host2/News/test2/test-1.html","http://hire-people.com/host2/News/test2/test-2.html","http://hire-people.com/host2/News/test2/test-3.html","http://hire-people.com/host2/News/test2/test-4.html","http://hire-people.com/host2/News/test2/test-5.html","http://hire-people.com/host2/News/test2/test-6.html"]

    @IBOutlet var UrlContentCollectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        fontSize = 100.0
        // Do any additional setup after loading the view.
      //  self.UrlContentCollectionView.isPagingEnabled = true
        let CheckfontsizeStr = UserDefaults.standard.value(forKey: "FontSize") as? String ?? "small"
        if CheckfontsizeStr == "small"{
             count = 1
            cssString = "body { font-size: 20px }"
        }else if CheckfontsizeStr == "midume"{
             count = 2
            cssString = "body { font-size: 25px }"
        }else{
             count = 0
            cssString = "body { font-size: 30px }"
        }
        
        menuHolderView.isHidden = true
        loadingHolderView.isHidden = true
        if pdfIdStr == ""{
            
        }else{
            UserDefaults.standard.set(pdfIdStr, forKey: "PdfIdForSearch")
        }
       
        UrlContentCollectionView!.isPagingEnabled = true
        
        let checkStr = UserDefaults.standard.value(forKey: "IsComeFromMenu") as? String ?? "false"
        if checkStr == "false"{
            newsImageHolderView.isHidden = false
            let userId = UserDefaults.standard.value(forKey: "UserId") as! String
            self.sk_data = SKDatabase(file: "NewsPaperDB.db")
            
            let GetAllIssue = "SELECT * FROM AllIssue where id='\(pdfIdStr)' and user_id='\(userId)'"
            
            let GetAllIssuedataArray1 = self.sk_data?.lookupAll(forSQL: GetAllIssue)
            
            let GetAllIssuensMutableArray2 = NSMutableArray(array: GetAllIssuedataArray1!)
            var array: NSMutableArray = NSMutableArray()
            array = GetAllIssuensMutableArray2.mutableCopy() as! NSMutableArray
            let imageStr = (array[0] as AnyObject) .value(forKey: "image_url") as? String ?? ""
            
            if let decodedData = Data(base64Encoded: imageStr, options: .ignoreUnknownCharacters) {
                newsImageView.image = UIImage(data: decodedData)
            }else{
                newsImageView.image = #imageLiteral(resourceName: "ic_splash_newspaper")
            }
            self.loadingActivity.startAnimating()
            self.sk_data = SKDatabase(file: "NewsPaperDB.db")
            
            let GetDownloadedTbl = "SELECT * FROM MenuTbl where news_id='\(pdfIdStr)' order by title ASC"
            
            let GetDownloadeddataArray1 = self.sk_data?.lookupAll(forSQL: GetDownloadedTbl)
            
            print(GetDownloadeddataArray1!)
            
            let GetDownloadedMutableArray2 = NSMutableArray(array: GetDownloadeddataArray1!)
            getSectionArray = GetDownloadedMutableArray2.mutableCopy() as! NSMutableArray
            
            UserDefaults.standard.setValue(self.getSectionArray, forKey: "MenuArray")
            
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "NotificationIdentifier"), object: nil)
            self.UrlContentCollectionView.reloadData()
            self.UrlContentCollectionView.layoutIfNeeded()
            //Set layout of collection view
            let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
            layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
            layout.itemSize = CGSize(width: self.view.frame.size.width, height: self.UrlContentCollectionView.frame.size.height)
            layout.minimumInteritemSpacing = 0
            layout.minimumLineSpacing = 1
            self.UrlContentCollectionView!.collectionViewLayout = layout
            self.UrlContentCollectionView.isScrollEnabled = true
            if let layout = self.UrlContentCollectionView.collectionViewLayout as? UICollectionViewFlowLayout {
                layout.scrollDirection = .horizontal
            }
        }else{
            newsImageHolderView.isHidden = true
            if checkStr == "false"{
                let reach = Reachability()
                if reach.isConnectedToNetwork() == true {
                    GetSection()
                }else{
                    loadingHolderView.isHidden = false
                    self.loadingActivity.startAnimating()
                    self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                    
                    let GetDownloadedTbl = "SELECT * FROM MenuTbl where news_id='\(pdfIdStr)' order by title ASC"
                    
                    let GetDownloadeddataArray1 = self.sk_data?.lookupAll(forSQL: GetDownloadedTbl)
                    
                    print(GetDownloadeddataArray1!)
                    
                    let GetDownloadedMutableArray2 = NSMutableArray(array: GetDownloadeddataArray1!)
                    getSectionArray = GetDownloadedMutableArray2.mutableCopy() as! NSMutableArray
                    
                    UserDefaults.standard.setValue(self.getSectionArray, forKey: "MenuArray")
                    
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "NotificationIdentifier"), object: nil)
                    self.UrlContentCollectionView.reloadData()
                    self.UrlContentCollectionView.layoutIfNeeded()
                    //Set layout of collection view
                    let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
                    layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
                    layout.itemSize = CGSize(width: self.view.frame.size.width, height: self.UrlContentCollectionView.frame.size.height)
                    layout.minimumInteritemSpacing = 0
                    layout.minimumLineSpacing = 1
                    self.UrlContentCollectionView!.collectionViewLayout = layout
                    self.UrlContentCollectionView.isScrollEnabled = true
                    if let layout = self.UrlContentCollectionView.collectionViewLayout as? UICollectionViewFlowLayout {
                        layout.scrollDirection = .horizontal
                    }
                }
            }else{
                loadingHolderView.isHidden = false
                self.loadingActivity.startAnimating()
                let array = (UserDefaults.standard.value(forKey: "MenuArray") as! NSArray).mutableCopy() as! NSMutableArray
                print(array)
                getSectionArray = array .mutableCopy() as! NSMutableArray
                 self.UrlContentCollectionView.reloadData()
                let index = UserDefaults.standard.value(forKey: "indexPath") as! String
                
                
                UrlContentCollectionView.layoutIfNeeded()
                //Set layout of collection view
                let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
                layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
                layout.itemSize = CGSize(width: self.view.frame.size.width, height: UrlContentCollectionView.frame.size.height)
                layout.minimumInteritemSpacing = 0
                layout.minimumLineSpacing = 0
                UrlContentCollectionView!.collectionViewLayout = layout
                UrlContentCollectionView.isScrollEnabled = true
                if let layout = self.UrlContentCollectionView.collectionViewLayout as? UICollectionViewFlowLayout {
                    layout.scrollDirection = .horizontal
                }
                
                let count = Int(index)
                print(count ?? 0)
                UrlContentCollectionView.scrollToItem(at: (NSIndexPath(item: count!, section: 0) as IndexPath), at: [], animated: false)
                //let indexPath = IndexPath(item: count!, section: 0)
              //  self.UrlContentCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
            }
        }
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        if UserDefaults.standard.value(forKey: "CallWillDisplayCell") as? String ?? "False" == "True"{
            let index = UserDefaults.standard.value(forKey: "indexPath") as! String
            let count = Int(index)
            print(count ?? 0)
            UrlContentCollectionView.scrollToItem(at: (NSIndexPath(item: count!, section: 0) as IndexPath), at: [], animated: false)
            UserDefaults.standard.set("False", forKey: "CallWillDisplayCell")
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        if touch?.view == self.menuHolderView {
            menuButtonHolderView.fadeOut()
            menuHolderView.isHidden = true
        }
    }

    
    // MARK: - CollectionView Deleget
     func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return (getSectionArray .value(forKey: "id") as AnyObject) .count
     }
    
     func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell:UrlCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "UrlCollectionViewCell", for: indexPath) as! UrlCollectionViewCell
        let reach = Reachability()
        if reach.isConnectedToNetwork() == true {
            let urlStr = (getSectionArray[indexPath.row] as AnyObject) .value(forKey: "post_url") as! String
            let url = URL(string: urlStr)
            cell.displayUrlWebView.loadRequest(URLRequest(url: url!))
        }else{
            let EncodeStr = (getSectionArray[indexPath.row] as AnyObject) .value(forKey: "HtmlWebView") as! String
            let decoded = EncodeStr.fromBase64()// Bundle.main.bundleURL
        
            cell.displayUrlWebView.loadHTMLString(decoded!, baseURL: nil)
        }
        cell.displayUrlWebView.scrollView.bounces = false
        cell.displayUrlWebView.scalesPageToFit = false
        let jsString = "var style = document.createElement('style'); style.innerHTML = '\(cssString)'; document.head.appendChild(style);"
        cell.displayUrlWebView.stringByEvaluatingJavaScript(from: jsString)
        
        cell.displayUrlWebView.delegate = self as? UIWebViewDelegate
       
        return cell
     }
    
    //MARK:- WebView Methods
    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        if let redirectURL = EVURLCache.shouldRedirect(request: request) {
            let r = URLRequest(url: redirectURL)
            webView.loadRequest(r)
            return false
        }
        return true
    }
  
    func webViewDidStartLoad(_ webView: UIWebView) {
       
    }
    func webViewDidFinishLoad(_ webView: UIWebView)
    {
        webView.scalesPageToFit = false
        //let cssString = "body { font-size: 30px }"
        let jsString = "var style = document.createElement('style'); style.innerHTML = '\(cssString)'; document.head.appendChild(style);"
        webView.stringByEvaluatingJavaScript(from: jsString)
        self.loadingActivity.stopAnimating()
        loadingHolderView.isHidden = true
    }
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        ACProgressHUD.shared.hideHUD()
        self.loadingActivity.stopAnimating()
        loadingHolderView.isHidden = true
    }
  
    //MARK:- Button Action Method
    @IBAction func moreMenuBtnClicked(_ sender: Any) {
        menuHolderView.isHidden = false
        menuButtonHolderView.fadeIn()
    }
    @IBAction func shareBtnClicked(_ sender: Any) {
        var indexStr: String = String()
        if let centerCellIndexPath = UrlContentCollectionView.centerCellIndexPath?.row {
            print(centerCellIndexPath)
            indexStr = "\(centerCellIndexPath)"
        }
        let intIndex = Int(indexStr)
        let shareUrlStr = (getSectionArray[intIndex!] as AnyObject) .value(forKey: "post_url") as? String ?? ""
        shareUrlStr.share()
    }
    @IBAction func promotionsBtnClicked(_ sender: Any) {
        menuButtonHolderView.fadeOut()
        menuHolderView.isHidden = true
        let appLinkStr = "Currently App Link Not Avaible"
        appLinkStr.share()
    }
    @IBAction func searchBtnClicked(_ sender: Any) {
        menuButtonHolderView.fadeOut()
        menuHolderView.isHidden = true
        let Search = self.storyboard?.instantiateViewController(withIdentifier: "SearchVC") as! SearchVC
        self.navigationController?.pushViewController(Search, animated: true)
    }
    @IBAction func resizeTextBtnClicked(_ sender: Any) {
        if count == 0{
            count = count + 1
            cssString = "body { font-size: 20px }"
        }else if count == 1{
            count = count + 1
            cssString = "body { font-size: 25px }"
        }else{
            count = 0
            cssString = "body { font-size: 30px }"
        }
        UrlContentCollectionView.reloadData()
        menuButtonHolderView.fadeOut()
        menuHolderView.isHidden = true
        
    }
    @IBAction func wishlistBtnClicked(_ sender: Any) {
        menuButtonHolderView.fadeOut()
        menuHolderView.isHidden = true
        let Wishlist = self.storyboard?.instantiateViewController(withIdentifier: "WishlistVC") as! WishlistVC
        self.navigationController?.pushViewController(Wishlist, animated: true)
    }
    @IBAction func deleteBtnClicked(_ sender: Any) {
        let reach = Reachability()
        if reach.isConnectedToNetwork() == true {
            DeletePdf()
        }else{
            let userId = UserDefaults.standard.value(forKey: "UserId") as! String
            self.sk_data = SKDatabase(file: "NewsPaperDB.db")
            let MemberHomeListTable = "DELETE FROM DownloadedTbl where user_id='\(userId)' and id='\(pdfIdStr)'"
            self.sk_data?.performSQL(MemberHomeListTable)
            menuButtonHolderView.fadeOut()
            menuHolderView.isHidden = true
            //News Delete Successfully
            let alert = UIAlertController(title: "Alert", message: "News Delete Successfully", preferredStyle:     UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    @IBAction func hideNewsImageBtnClicked(_ sender: Any) {
        
        newsImageHolderView.rightToleft()
        
        let checkStr = UserDefaults.standard.value(forKey: "IsComeFromMenu") as? String ?? "false"
        if checkStr == "false"{
            let reach = Reachability()
            if reach.isConnectedToNetwork() == true {
                GetSection()
            }else{
                loadingHolderView.isHidden = false
                self.loadingActivity.startAnimating()
                self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                
                let GetDownloadedTbl = "SELECT * FROM MenuTbl where news_id='\(pdfIdStr)'"
                
                let GetDownloadeddataArray1 = self.sk_data?.lookupAll(forSQL: GetDownloadedTbl)
                
                print(GetDownloadeddataArray1!)
                
                let GetDownloadedMutableArray2 = NSMutableArray(array: GetDownloadeddataArray1!)
                getSectionArray = GetDownloadedMutableArray2.mutableCopy() as! NSMutableArray
                
                UserDefaults.standard.setValue(self.getSectionArray, forKey: "MenuArray")
                
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "NotificationIdentifier"), object: nil)
                self.UrlContentCollectionView.reloadData()
                self.UrlContentCollectionView.layoutIfNeeded()
                //Set layout of collection view
                let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
                layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
                layout.itemSize = CGSize(width: self.view.frame.size.width, height: self.UrlContentCollectionView.frame.size.height)
                layout.minimumInteritemSpacing = 0
                layout.minimumLineSpacing = 1
                self.UrlContentCollectionView!.collectionViewLayout = layout
                self.UrlContentCollectionView.isScrollEnabled = true
                if let layout = self.UrlContentCollectionView.collectionViewLayout as? UICollectionViewFlowLayout {
                    layout.scrollDirection = .horizontal
                }
            }
        }else{
            loadingHolderView.isHidden = false
            self.loadingActivity.startAnimating()
            let array = (UserDefaults.standard.value(forKey: "MenuArray") as! NSArray).mutableCopy() as! NSMutableArray
            print(array)
            getSectionArray = array .mutableCopy() as! NSMutableArray
            self.UrlContentCollectionView.reloadData()
            let index = UserDefaults.standard.value(forKey: "indexPath") as! String
            
            
            UrlContentCollectionView.layoutIfNeeded()
            //Set layout of collection view
            let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
            layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
            layout.itemSize = CGSize(width: self.view.frame.size.width, height: UrlContentCollectionView.frame.size.height)
            layout.minimumInteritemSpacing = 0
            layout.minimumLineSpacing = 0
            UrlContentCollectionView!.collectionViewLayout = layout
            UrlContentCollectionView.isScrollEnabled = true
            if let layout = self.UrlContentCollectionView.collectionViewLayout as? UICollectionViewFlowLayout {
                layout.scrollDirection = .horizontal
            }
            
            let count = Int(index)
            print(count ?? 0)
            let indexPath = IndexPath(item: count!, section: 0)
            self.UrlContentCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        }
    }
    
    
    //MARK: - Get Section PDF
    func GetSection(){
        
        ACProgressHUD.shared.showHUD()
        
        DispatchQueue.global(qos: .background).async {
            //http://hire-people.com/host2/news_wp/api/subpages.php?news_id=132
            
            let myUrl = URL(string: GlobalUrl.BaseUrl + "subpages.php?");
            var request = URLRequest(url:myUrl!)
            request.httpMethod = "POST"
            _ = UserDefaults.standard.value(forKey: "UserId") as! String
            
            let postString = "news_id=" + self.pdfIdStr
            print(postString)
            let userName = "admin"
            let password = "admin"
            var _: Error? = nil
            let authStr = "\(userName):\(password)"
            let authData: Data? = authStr.data(using: .ascii)
            let authStrData = String(data: authData?.base64EncodedData(options: .endLineWithLineFeed) ?? Data(), encoding: .ascii)
            let authValue = "Basic \(authStrData!)"
            request.addValue(authValue, forHTTPHeaderField: "Authorization")
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                
                if error != nil
                {
                    ACProgressHUD.shared.hideHUD()
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error!)
                    
                    return
                }
                
                print("response = \(response!)")
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    DispatchQueue.main.async {
                        
                        if let parseJSON = json {
                            
                            print(parseJSON)
                            let status =   parseJSON["status"] as! String
                            
                            if status == "true"{
                                ACProgressHUD.shared.hideHUD()
                              
                                let dataDic = parseJSON["data"] as AnyObject
                                self.getSectionArray = dataDic as! NSMutableArray
                                
                                var idStr: String = String()
                                var titleStr: String = String()
                                var post_url: String = String()
                                
                                for i in 0..<self.getSectionArray.count{
                                    let id = (self.getSectionArray[i] as AnyObject) .value(forKey: "id") as! NSNumber
                                    idStr = "\(id)"
                                    titleStr = (self.getSectionArray[i] as AnyObject) .value(forKey: "title") as? String ?? ""
                                    post_url = (self.getSectionArray[i] as AnyObject) .value(forKey: "post_url") as? String ?? ""
                                    
                                    self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                    
                                    let Premimum = "SELECT * FROM MenuTbl where id='\(idStr)' and news_id='\(self.pdfIdStr)'"
                                    
                                    let dataArray1 = self.sk_data?.lookupAll(forSQL: Premimum)
                                    
                                    print(dataArray1!)
                                    
                                    let nsMutableArray5 = NSMutableArray(array: dataArray1!)
                                    
                                    let array = nsMutableArray5 .mutableCopy() as! NSMutableArray
                                    if array.count == 0{
                                        self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                        let InsertAllIssue = "insert into MenuTbl (id,title,post_url,news_id) VALUES ('\(idStr)','\(titleStr)','\(post_url)','\(self.pdfIdStr)')"
                                        let st1: Bool =  ((self.sk_data?.performSQL(InsertAllIssue)) != nil)
                                        if st1 {
                                            print("Data Insert")
                                        }
                                        else {
                                            print("Data Not Insert")
                                        }
                                        
                                    }else{
                                        self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                        let updateAllIssue = "UPDATE MenuTbl SET title='\(titleStr)',post_url='\(post_url)' WHERE id='\(idStr)' and news_id='\(self.pdfIdStr)'"
                                        print(updateAllIssue)
                                        self.sk_data?.performSQL(updateAllIssue)
                                        
                                    }
                                }
                                
                                self.UrlContentCollectionView.reloadData()
                                self.UrlContentCollectionView.layoutIfNeeded()
                                //Set layout of collection view
                                let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
                                layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
                                layout.itemSize = CGSize(width: self.view.frame.size.width, height: self.UrlContentCollectionView.frame.size.height)
                                layout.minimumInteritemSpacing = 0
                                layout.minimumLineSpacing = 1
                                self.UrlContentCollectionView!.collectionViewLayout = layout
                                self.UrlContentCollectionView.isScrollEnabled = true
                                if let layout = self.UrlContentCollectionView.collectionViewLayout as? UICollectionViewFlowLayout {
                                    layout.scrollDirection = .horizontal
                                }
                                
                                UserDefaults.standard.setValue(self.getSectionArray, forKey: "MenuArray")
                                
                                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "NotificationIdentifier"), object: nil)
                                self.loadingHolderView.isHidden = false
                                self.loadingActivity.startAnimating()
                                
                            }else{
                                ACProgressHUD.shared.hideHUD()
                                let alert = UIAlertController(title: "ERROR", message:"Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                                
                            }
                        }
                    }
                }
                catch {
                    ACProgressHUD.shared.hideHUD()
                    
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error)
                }
            }
            task.resume()
        }
    }
    
    //MARK:- Delete Pdf From Download
    func DeletePdf(){
        
        ACProgressHUD.shared.showHUD()
        
        DispatchQueue.global(qos: .background).async {
            //http://hire-people.com/host2/news_wp/api/delete_api.php?user_id=21&page_id=10
            
            let myUrl = URL(string: GlobalUrl.BaseUrl + "delete_api.php?");
            var request = URLRequest(url:myUrl!)
            request.httpMethod = "POST"
            let userId = UserDefaults.standard.value(forKey: "UserId") as! String
            
            let postString = "user_id=" + userId + "&page_id=" + self.pdfIdStr
            print(postString)
            let userName = "admin"
            let password = "admin"
            var _: Error? = nil
            let authStr = "\(userName):\(password)"
            let authData: Data? = authStr.data(using: .ascii)
            let authStrData = String(data: authData?.base64EncodedData(options: .endLineWithLineFeed) ?? Data(), encoding: .ascii)
            let authValue = "Basic \(authStrData!)"
            request.addValue(authValue, forHTTPHeaderField: "Authorization")
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                
                if error != nil
                {
                    ACProgressHUD.shared.hideHUD()
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error!)
                    
                    return
                }
                
                print("response = \(response!)")
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    DispatchQueue.main.async {
                        
                        if let parseJSON = json {
                            
                            print(parseJSON)
                            let status =   parseJSON["status"] as! String
                            
                            if status == "true"{
                                ACProgressHUD.shared.hideHUD()
                                self.menuButtonHolderView.fadeOut()
                                self.menuHolderView.isHidden = true
                                self.sk_data = SKDatabase(file: "NewsPaperDB.db")
                                let MemberHomeListTable = "DELETE FROM DownloadedTbl where user_id='\(userId)' and id='\(self.pdfIdStr)'"
                                self.sk_data?.performSQL(MemberHomeListTable)
                                
                                let msg = parseJSON["msg"] as! String
                                let alert = UIAlertController(title: "Alert", message: msg, preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                            }else{
                                ACProgressHUD.shared.hideHUD()
                                let alert = UIAlertController(title: "ERROR", message:"Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                                
                            }
                        }
                    }
                }
                catch {
                    ACProgressHUD.shared.hideHUD()
                    
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error)
                }
            }
            task.resume()
        }
    }

}
extension UIWebView {
    ///Method to fit content of webview inside webview according to different screen size
    func resizeWebContent() {
        let contentSize = self.scrollView.contentSize
        let viewSize = self.bounds.size
        let zoomScale = viewSize.width/contentSize.width
        self.scrollView.minimumZoomScale = zoomScale
        self.scrollView.maximumZoomScale = zoomScale
        self.scrollView.zoomScale = zoomScale
    }
}

extension UIApplication {
    
    class var topViewController: UIViewController? {
        return getTopViewController()
    }
    
    private class func getTopViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let nav = base as? UINavigationController {
            return getTopViewController(base: nav.visibleViewController)
        }
        if let tab = base as? UITabBarController {
            if let selected = tab.selectedViewController {
                return getTopViewController(base: selected)
            }
        }
        if let presented = base?.presentedViewController {
            return getTopViewController(base: presented)
        }
        return base
    }
}

extension Equatable {
    func share() {
        let activity = UIActivityViewController(activityItems: [self], applicationActivities: nil)
        UIApplication.topViewController?.present(activity, animated: true, completion: nil)
    }
}

extension UICollectionView {
    
    var centerPoint : CGPoint {
        
        get {
            return CGPoint(x: self.center.x + self.contentOffset.x, y: self.center.y + self.contentOffset.y);
        }
    }
    
    var centerCellIndexPath: IndexPath? {
        
        if let centerIndexPath = self.indexPathForItem(at: self.centerPoint) {
            return centerIndexPath
        }
        return nil
    }
}
extension String {
    /// Encode a String to Base64
    func toBase64() -> String {
        return Data(self.utf8).base64EncodedString()
    }
    
    /// Decode a String from Base64. Returns nil if unsuccessful.
    func fromBase64() -> String? {
        guard let data = Data(base64Encoded: self) else { return nil }
        return String(data: data, encoding: .utf8)
    }
}
