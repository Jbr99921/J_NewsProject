//
//  UrlCollectionViewCell.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 21/01/19.
//  Copyright © 2019 Archirayan. All rights reserved.
//

import UIKit

class UrlCollectionViewCell: UICollectionViewCell {
    @IBOutlet var displayUrlWebView: UIWebView!
    
}
