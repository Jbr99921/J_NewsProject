//
//  GeneralVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 06/02/19.
//  Copyright © 2019 Archirayan. All rights reserved.
//

import UIKit
import MessageUI

class GeneralVC: UIViewController,MFMailComposeViewControllerDelegate {
    
   
    
    var attrs : [NSAttributedStringKey : Any] = [
        NSAttributedStringKey.font : UIFont.systemFont(ofSize: 15.0),
        NSAttributedStringKey.foregroundColor : UIColor(red: 31/255.0, green: 68/255.0, blue: 161/255.0, alpha: 1.0),
        NSAttributedStringKey.underlineStyle : NSUnderlineStyle.styleSingle.rawValue
    ]

    @IBOutlet var mailBtn: UIButton!
    @IBOutlet var wifiSwitch: UISwitch!
    @IBOutlet var mobileDataSwitch: UISwitch!
    @IBOutlet var bigFontBtn: UIButton!
    @IBOutlet var miduemFontBtn: UIButton!
    @IBOutlet var smallFontBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let fontSizeStr = UserDefaults.standard.value(forKey: "FontSize") as? String ?? "small"
        if fontSizeStr == "small"{
            smallFontBtn.setTitleColor(UIColor(red: 31/255.0, green: 68/255.0, blue: 161/255.0, alpha: 1.0), for: UIControlState.normal)
            miduemFontBtn.setTitleColor(UIColor.lightGray, for: UIControlState.normal)
            bigFontBtn.setTitleColor(UIColor.lightGray, for: UIControlState.normal)
        }else if fontSizeStr == "midume"{
            smallFontBtn.setTitleColor(UIColor.lightGray, for: UIControlState.normal)
            miduemFontBtn.setTitleColor(UIColor(red: 31/255.0, green: 68/255.0, blue: 161/255.0, alpha: 1.0), for: UIControlState.normal)
            bigFontBtn.setTitleColor(UIColor.lightGray, for: UIControlState.normal)
        }else{
            smallFontBtn.setTitleColor(UIColor.lightGray, for: UIControlState.normal)
            miduemFontBtn.setTitleColor(UIColor.lightGray, for: UIControlState.normal)
            bigFontBtn.setTitleColor(UIColor(red: 31/255.0, green: 68/255.0, blue: 161/255.0, alpha: 1.0), for: UIControlState.normal)
        }
        
        let attributeString = NSMutableAttributedString(string: "metroapps@metro.co.uk",
                                                        attributes: attrs)
        mailBtn.setAttributedTitle(attributeString, for: .normal)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Button Action Method
    @IBAction func backButtonClicked(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    @IBAction func smallFontBtnClicked(_ sender: Any) {
        UserDefaults.standard.set("small", forKey: "FontSize")
        smallFontBtn.setTitleColor(UIColor(red: 31/255.0, green: 68/255.0, blue: 161/255.0, alpha: 1.0), for: UIControlState.normal)
        miduemFontBtn.setTitleColor(UIColor.lightGray, for: UIControlState.normal)
        bigFontBtn.setTitleColor(UIColor.lightGray, for: UIControlState.normal)
    }
    @IBAction func miduemFontBtnClicked(_ sender: Any) {
        UserDefaults.standard.set("midume", forKey: "FontSize")
        smallFontBtn.setTitleColor(UIColor.lightGray, for: UIControlState.normal)
        miduemFontBtn.setTitleColor(UIColor(red: 31/255.0, green: 68/255.0, blue: 161/255.0, alpha: 1.0), for: UIControlState.normal)
        bigFontBtn.setTitleColor(UIColor.lightGray, for: UIControlState.normal)
    }
    @IBAction func bigFontBtnClicked(_ sender: Any) {
        UserDefaults.standard.set("big", forKey: "FontSize")
        smallFontBtn.setTitleColor(UIColor.lightGray, for: UIControlState.normal)
        miduemFontBtn.setTitleColor(UIColor.lightGray, for: UIControlState.normal)
        bigFontBtn.setTitleColor(UIColor(red: 31/255.0, green: 68/255.0, blue: 161/255.0, alpha: 1.0), for: UIControlState.normal)
    }
    @IBAction func mailBtnClicked(_ sender: Any) {
        let emailStr = "metroapps@metro.co.uk"
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        mailComposerVC.setToRecipients([emailStr])
        mailComposerVC.setSubject("")
        mailComposerVC.setMessageBody("", isHTML: false)
        self.present(mailComposerVC, animated: true, completion: nil)
    }
    


}
