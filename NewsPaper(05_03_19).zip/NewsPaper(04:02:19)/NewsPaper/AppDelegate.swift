//
//  AppDelegate.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 05/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//  Created by archirayan on 4/12/18.
//  Author:www.archirayan.com
//  Email:info@archirayan.com
//

import UIKit
import FBSDKLoginKit
import FBSDKCoreKit
import EVURLCache
import FacebookCore
import FacebookLogin
import FacebookShare
import GoogleSignIn


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, GIDSignInDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
        IQKeyboardManager.shared.keyboardDistanceFromTextField = 60
        
        EVURLCache.LOGGING = true // We want to see all caching actions
        EVURLCache.MAX_FILE_SIZE = 26 // We want more than the default: 2^26 = 64MB
        EVURLCache.MAX_CACHE_SIZE = 30 // We want more than the default: 2^30 = 1GB
        EVURLCache.activate()
        
       // FBSDKApplicationDelegate.sharedInstance().application(application, didFinishLaunchingWithOptions: launchOptions)
        
         GIDSignIn.sharedInstance()?.clientID = "46115169303-agov3hh6hepgv7o564qm972i7gpdj5re.apps.googleusercontent.com"
    
        
        UserDefaults.standard.set("true", forKey: "GetMenu")
        UserDefaults.standard.set("false", forKey: "IsComeFromMenu")
        
        // DashbordNV
        if UserDefaults.standard.value(forKey: Key.is_UserLogin) as? String == "True"{
            let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
            let navigationController = storyboard.instantiateViewController(withIdentifier: "DashbordNV") as! UINavigationController
            let mainViewController = storyboard.instantiateViewController(withIdentifier: "SideMenuViewController") as! SideMenuViewController
            mainViewController.rootViewController = navigationController
            navigationController.isNavigationBarHidden = true
            let window = UIApplication.shared.delegate!.window!!
            window.rootViewController = mainViewController
        }else{
            // HomeNV
            let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
            let navigationController = storyboard.instantiateViewController(withIdentifier: "HomeNV") as! UINavigationController
            let mainViewController = storyboard.instantiateViewController(withIdentifier: "SideMenuViewController") as! SideMenuViewController
            mainViewController.rootViewController = navigationController
            navigationController.isNavigationBarHidden = true
            let window = UIApplication.shared.delegate!.window!!
            window.rootViewController = mainViewController
        }
        SDKApplicationDelegate.shared.application(application, didFinishLaunchingWithOptions: launchOptions)
        return true
    }
    
    private func application(_ app: UIApplication, open url: URL, options: [UIApplicationLaunchOptionsKey : Any] = [:]) -> Bool {
        
        return SDKApplicationDelegate.shared.application(app, open: url, options: options)
    }
    
    func application(_ app: UIApplication, open url: URL, options: [UIApplicationOpenURLOptionsKey : Any] = [:]) -> Bool {
        let handled = FBSDKApplicationDelegate.sharedInstance().application(app, open: url, options: options)
        return handled
    }
    
    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        
        var _: [String: AnyObject] = [UIApplicationOpenURLOptionsKey.sourceApplication.rawValue: sourceApplication as AnyObject,
                                      UIApplicationOpenURLOptionsKey.annotation.rawValue: annotation as AnyObject]
        
        _ = GIDSignIn.sharedInstance().handle(url,
                                                            sourceApplication: sourceApplication,
                                                            annotation: annotation)
        
        
        return SDKApplicationDelegate.shared.application(application, open: url as URL, sourceApplication: sourceApplication, annotation: annotation)//googlSignIn// || handled
    }
    
    func sign(_ signIn: GIDSignIn!, didDisconnectWith user: GIDGoogleUser!,
              withError error: Error!) {
        // Perform any operations when the user disconnects from app here.
        // ...
    }
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!,
              withError error: Error!) {
        if let error = error {
            print("\(error.localizedDescription)")
        } else {
            // Perform any operations on signed in user here.
            _ = user.userID                  // For client-side use only!
            _ = user.authentication.idToken // Safe to send to the server
            _ = user.profile.name
            _ = user.profile.givenName
            _ = user.profile.familyName
            _ = user.profile.email
            // ...
        }
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        let deviceTokenString = deviceToken.reduce("", {$0 + String(format: "%02X", $1)})
        print(deviceTokenString)
        UserDefaults.standard.set(deviceTokenString , forKey: "DeviceToken")
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        
        print("i am not available in simulator \(error)")
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        FBSDKAppEvents.activateApp()
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

