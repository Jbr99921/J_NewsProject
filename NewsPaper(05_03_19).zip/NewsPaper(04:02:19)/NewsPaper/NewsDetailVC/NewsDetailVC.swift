//
//  NewsDetailVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 21/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//

import UIKit

class NewsDetailVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var dateArray: NSMutableArray = NSMutableArray()

    @IBOutlet var mainTitleLabel: UILabel!
    @IBOutlet var newsDetailListTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        GetNewsData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (dateArray .value(forKey: "id") as AnyObject).count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:newsDetailListTVC = tableView.dequeueReusableCell(withIdentifier: "newsDetailListTVC")
            as! newsDetailListTVC
        cell.detailLabel.text = (dateArray[indexPath.row] as AnyObject) .value(forKey: "description") as? String
        cell.titleLabel.text = (dateArray[indexPath.row] as AnyObject) .value(forKey: "title") as? String
        cell.byLabel.text = (dateArray[indexPath.row] as AnyObject) .value(forKey: "by") as? String
        
        let imageUrl = (dateArray[indexPath.row] as AnyObject) .value(forKey: "images") as! String
        if let data = NSData(contentsOf: NSURL(string:imageUrl as String )! as URL) {
            cell.newsImageLabel.image = UIImage(data: data as Data)
        }
        
        return cell
        
    }
    
    
    
    //MARK: - Get News Data
    func GetNewsData(){
        
        ACProgressHUD.shared.showHUD()
        
        DispatchQueue.global(qos: .background).async {
            //http://easydatasearch.com/easydata1/News/apis/api_title.php?id=13
            
            let myUrl = URL(string: GlobalUrl.BaseUrl + "api_title.php?");
            var request = URLRequest(url:myUrl!)
            request.httpMethod = "POST"
            
            var postString: String = String()
            let idStr = UserDefaults.standard.value(forKey: "MenuID") as? String ?? "1"
            
            postString = "id=" + idStr
            
            
            UserDefaults.standard.set("false", forKey: "IsComeFromMenu")
            
            let userName = "admin"
            let password = "admin"
            var _: Error? = nil
            let authStr = "\(userName):\(password)"
            let authData: Data? = authStr.data(using: .ascii)
            let authStrData = String(data: authData?.base64EncodedData(options: .endLineWithLineFeed) ?? Data(), encoding: .ascii)
            let authValue = "Basic \(authStrData!)"
            request.addValue(authValue, forHTTPHeaderField: "Authorization")
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                
                if error != nil
                {
                    ACProgressHUD.shared.hideHUD()
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error!)
                    
                    return
                }
                
                print("response = \(response!)")
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    DispatchQueue.main.async {
                        
                        if let parseJSON = json {
                            
                            print(parseJSON)
                            let status =   parseJSON["status"] as! String
                            
                            if status == "true"{
                                ACProgressHUD.shared.hideHUD()//1
                                let dataDic = parseJSON["data"] as AnyObject
                                self.dateArray = dataDic as! NSMutableArray
                                if self.dateArray.count == 0{
                                    let alert = UIAlertController(title: "Alert", message:"News Not Found", preferredStyle:     UIAlertControllerStyle.alert)
                                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                self.newsDetailListTableView.reloadData()
                                self.mainTitleLabel.text = (self.dateArray[0] as AnyObject) .value(forKey: "title") as? String
                                
                            
                            }else{
                                ACProgressHUD.shared.hideHUD()
                                let alert = UIAlertController(title: "ERROR", message:"News Not Found", preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                                
                            }
                        }
                    }
                }
                catch {
                    ACProgressHUD.shared.hideHUD()
                    
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error)
                }
            }
            task.resume()
        }
    }
}
