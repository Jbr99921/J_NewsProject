//
//  newsDetailListTVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 21/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//

import UIKit

class newsDetailListTVC: UITableViewCell {
    
    @IBOutlet var newsImageLabel: UIImageView!
    @IBOutlet var byLabel: UILabel!
    @IBOutlet var detailLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
