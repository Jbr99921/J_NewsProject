//
//  FAQVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 13/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//

import UIKit
import EVURLCache

class FAQVC: UIViewController, UIWebViewDelegate {
    
    @IBOutlet var faqWebView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.//FAQHtml
        let image = #imageLiteral(resourceName: "ic_splash_newspaper")
        var imageData = UIImagePNGRepresentation(image)
        let base64String = imageData?.base64EncodedString(options: .lineLength64Characters)
        let html = "<img src=data:image/png;base64,'\(base64String!)'/></div>"
        
        /*"<div><p>Taken from wikpedia</p> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO9TXL0Y4OHwAAAABJRU5ErkJggg=="alt="Red dot" /></div>"*/
        
       // let data = base64String?.data(using: String.Encoding(rawValue: String.Encoding.utf8.rawValue))
        faqWebView.loadHTMLString(html, baseURL: nil)
       // faqWebView.load(data!, mimeType: "text/html", textEncodingName: "UTF-8", baseURL: "")
        //faqWebView.LoadData(nsdata, "text/html", "UTF-8")
        //uiWebView.LoadData(nsdata, "text/html", "UTF-8", new NSUrl(""));
        
      /*  let reach = Reachability()
        if reach.isConnectedToNetwork() == true {
            faqWebView.delegate = self
            faqWebView.scrollView.bounces = false
            let urlStr = URL(string: "http://hire-people.com/host2/news_wp/faq/")
            faqWebView.loadRequest(URLRequest(url: urlStr!))
            ACProgressHUD.shared.showHUD()
        }else{
            let htmlstr = UserDefaults.standard.value(forKey: "FAQHtml") as! String
            faqWebView.loadHTMLString(htmlstr, baseURL: nil)
            ACProgressHUD.shared.showHUD()
        }*/
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func webViewDidStartLoad(_ webView: UIWebView) {
        // ACProgressHUD.shared.showHUD()
    }
    func webViewDidFinishLoad(_ webView: UIWebView)
    {
        ACProgressHUD.shared.hideHUD()
    }
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        ACProgressHUD.shared.hideHUD()
    }
    
    //MARK:- WebView Methods
    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        if let redirectURL = EVURLCache.shouldRedirect(request: request) {
            let r = URLRequest(url: redirectURL)
            webView.loadRequest(r)
            return false
        }
        return true
    }
    
    // MARK: - Button Action Method
    @IBAction func backButtonClicked(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }
}
