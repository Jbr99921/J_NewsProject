//
//  SignINVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 04/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//  Created by archirayan on 4/12/18.
//  Author:www.archirayan.com
//  Email:info@archirayan.com
//

import UIKit
import FacebookLogin
import FacebookCore
import FBSDKCoreKit
import FBSDKLoginKit
import GoogleSignIn

class SignINVC: UIViewController, GIDSignInDelegate, GIDSignInUIDelegate {
    
    var FacbookUserDict : NSDictionary = NSDictionary()
    
    var SocialUserNameStr: String = String()
    var SocialEmailStr: String = String()
    var SocialTokenStr: String = String()
    var SocialIdStr: String = String()
    
    @IBOutlet var FaceBookBtn: UIButton!

    @IBOutlet var hideShowPasswordButton: UIButton!
    @IBOutlet var signINBtn: UIButton!
    @IBOutlet var passwordTxt: VCTextField!
    @IBOutlet var emailOrUsernameTxt: VCTextField!
    
    var isComeFrom: String = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        GIDSignIn.sharedInstance().uiDelegate = self as? GIDSignInUIDelegate
        

        // Do any additional setup after loading the view.
        signINBtn.layer.cornerRadius = 5
        hideShowPasswordButton.isSelected = true
        passwordTxt.isSecureTextEntry = true
        
        if let accessToken = AccessToken.current {
            // Add Access Token here
        }
        
        var loginButton = LoginButton(readPermissions: [ .publicProfile ])
        loginButton = LoginButton(readPermissions: [ .publicProfile, .email, .userFriends ])
        
        
        if isComeFrom == "SignUP"{
            ACProgressHUD.shared.hideHUD()
            let alert = UIAlertController(title: "Alert", message:"Registration Sussesfully", preferredStyle:     UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else if isComeFrom == "ForgotPaasword"{
            let alert = UIAlertController(title: "Alert", message:"Password Update Sussesfully", preferredStyle:     UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
         FHSTwitterEngine.shared().permanentlySetConsumerKey("qfAaKCoAR9fganaK1vk7G8Xn0", andSecret: "fBKYdmElNgghMaoHAIubrP90BZTHveGf1nLtmOrjvCD6ZGpaol")
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //MARK:- Google SignIn Method
    // Stop the UIActivityIndicatorView animation that was started when the user
    // pressed the Sign In button
    func sign(inWillDispatch signIn: GIDSignIn!, error: Error?) {
        // UIActivityIndicatorView.stopAnimating()
    }
    
    // Present a view that prompts the user to sign in with Google
    func sign(_ signIn: GIDSignIn!,
              present viewController: UIViewController!) {
        self.present(viewController, animated: true, completion: nil)
    }
    
    // Dismiss the "Sign in with Google" view
    func sign(_ signIn: GIDSignIn!,
              dismiss viewController: UIViewController!) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!,
              withError error: Error!) {
        if let error = error {
            print("\(error.localizedDescription)")
        } else {
            // Perform any operations on signed in user here.
            SocialIdStr = user.userID
            // let idToken = user.authentication.idToken // Safe to send to the server
            // GoogleTokenStr = user.authentication.idToken
            SocialUserNameStr = user.profile.name
            // let givenName = user.profile.givenName
            // let familyName = user.profile.familyName
            SocialEmailStr = user.profile.email
            self.GoogleLoginDataToDataBase()
        }
    }
    
    // MARK: - Button Action Method
    
    @IBAction func signInButtonClicked(_ sender: Any) {
       LogingFromDatabase()
    }
    @IBAction func signUpButtonClicked(_ sender: Any) {
        let SignUp = self.storyboard?.instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
        self.navigationController?.pushViewController(SignUp, animated: true)
    }
    @IBAction func forgotPasswordButtonClicked(_ sender: Any) {
        let ForgotPassword = self.storyboard?.instantiateViewController(withIdentifier: "ForgotPasswordVC") as! ForgotPasswordVC
        self.navigationController?.pushViewController(ForgotPassword, animated: true)
    }
    @IBAction func HideandShowPasswordBtnClicked(_ sender: Any) {
        if hideShowPasswordButton.isSelected == true{
            hideShowPasswordButton.setBackgroundImage(#imageLiteral(resourceName: "ic_hide_psw_off"), for: .normal)
            passwordTxt.isSecureTextEntry = false
            hideShowPasswordButton.isSelected = false
        }else{
            hideShowPasswordButton.setBackgroundImage(#imageLiteral(resourceName: "view"), for: .normal)
            passwordTxt.isSecureTextEntry = true
            hideShowPasswordButton.isSelected = true
        }
    }
    @IBAction func TwitterSignInButtonClicked(_ sender: Any) {
        FHSTwitterEngine.shared().clearAccessToken()
        let login =    FHSTwitterEngine.shared().loginController { (success) in
            print("Login")
            let IDstr = FHSTwitterEngine.shared().authenticatedID
            print(IDstr ?? "No ID Found")
            // UserDefaults.standard.set(IDstr, forKey: "UserID")
            let userName = FHSTwitterEngine.shared().authenticatedUsername
            print(userName ?? "No UserName Found")
            // UserDefaults.standard.set(userName, forKey: "UserName")
            let Home = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
            self.navigationController?.pushViewController(Home, animated: true)
            } as UIViewController
        self.present(login, animated: true, completion: nil)
       
    }
    @IBAction func googleSignInBtnClicked(_ sender: Any) {
       
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().signIn()
        
    }
    
    @IBAction func FacebookLoginBtnClicked(_ sender: Any) {
        
        let login = FBSDKLoginManager()
        login.logOut()
        login.logIn(withReadPermissions: ["public_profile", "email"], from: self, handler: {(result, error) -> Void in
            if error != nil {
                print("Process error")
            }
            else if (result?.isCancelled)! {
                print("Cancelled")
            }
            else {
                print("Logged in")
                DispatchQueue.main.async(execute: {
                    print("okkkkkk")
                    self.getFBUserData()
                })
            }
            
        })
    }
    
    //MARK:- Get Facebook User Data
    func getFBUserData(){
        if((FBSDKAccessToken.current()) != nil){
            FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, picture.type(large), email"]).start(completionHandler: { (connection, result, error) -> Void in
                if (error == nil){
                    self.FacbookUserDict = result as! NSDictionary
                    print(self.FacbookUserDict)
                    self.SocialUserNameStr = self.FacbookUserDict .value(forKey: "name") as? String ?? ""
                    print(self.SocialUserNameStr)
                    self.SocialEmailStr = self.FacbookUserDict .value(forKey: "email") as? String ?? ""
                    print(self.SocialEmailStr)
                    self.SocialIdStr = self.FacbookUserDict .value(forKey: "id") as? String ?? ""
                    print(self.SocialIdStr)
                    self.FaceBookLoginDataToDataBase()
                   
                }
            })
        }
    }
    //MARK: - Login From Database
    func LogingFromDatabase(){
        
        ACProgressHUD.shared.showHUD()
        
        DispatchQueue.global(qos: .background).async {
            //http://hire-people.com/host2/news_wp/api/login.php?username_email=archirayan80&&password=4565
            
            let myUrl = URL(string: GlobalUrl.BaseUrl + "login.php?");
            print(myUrl!)
            var request = URLRequest(url:myUrl!)
            request.httpMethod = "POST"
            
            let postString = "username_email=" + self.emailOrUsernameTxt.text! + "&password=" + self.passwordTxt.text!
            
            let userName = "admin"
            let password = "admin"
            var _: Error? = nil
            let authStr = "\(userName):\(password)"
            let authData: Data? = authStr.data(using: .ascii)
            let authStrData = String(data: authData?.base64EncodedData(options: .endLineWithLineFeed) ?? Data(), encoding: .ascii)
            let authValue = "Basic \(authStrData!)"
            request.addValue(authValue, forHTTPHeaderField: "Authorization")
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                
                if error != nil
                {
                    ACProgressHUD.shared.hideHUD()
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error!)
                    
                    return
                }
                
                print("response = \(response!)")
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    DispatchQueue.main.async {
                        
                        if let parseJSON = json {
                            
                            print(parseJSON)
                            let status =   parseJSON["status"] as! String
                            
                            if status == "true"{
                                ACProgressHUD.shared.hideHUD()
                                let dataArray = parseJSON["data"] as AnyObject
                                let userId = dataArray.value(forKey:"ID") as! String
                                print(userId)
                                UserDefaults.standard.set(userId, forKey: "UserId")
                                UserDefaults.standard.set("True", forKey: Key.is_UserLogin)
                                let Home = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
                                self.navigationController?.pushViewController(Home, animated: true)
                            }else{
                                ACProgressHUD.shared.hideHUD()
                                let alert = UIAlertController(title: "ERROR", message:"User Name or Password Wrong", preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                            }
                        }
                    }
                }
                catch {
                    ACProgressHUD.shared.hideHUD()
                    
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error)
                }
            }
            task.resume()
        }
    }
    
    //MARK: - Facebook Login Data Send To Database
    func FaceBookLoginDataToDataBase(){
        
        ACProgressHUD.shared.showHUD()
        
        DispatchQueue.global(qos: .background).async {
            
            
            let myUrl = URL(string: GlobalUrl.BaseUrl + "login_with_facebook.php?");
            print(myUrl!)
            var request = URLRequest(url:myUrl!)
            request.httpMethod = "POST"
            let tokenStr = UserDefaults.standard.value(forKey: "DeviceToken") as? String ?? ""
            let postString = "email=" + self.SocialEmailStr + "&token_id=" + tokenStr + "&full_name=" + self.SocialUserNameStr + "&deviceType=IOS"
            
            let userName = "admin"
            let password = "admin"
            var _: Error? = nil
            let authStr = "\(userName):\(password)"
            let authData: Data? = authStr.data(using: .ascii)
            let authStrData = String(data: authData?.base64EncodedData(options: .endLineWithLineFeed) ?? Data(), encoding: .ascii)
            let authValue = "Basic \(authStrData!)"
            request.addValue(authValue, forHTTPHeaderField: "Authorization")
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                
                if error != nil
                {
                    ACProgressHUD.shared.hideHUD()
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error!)
                    
                    return
                }
                
                print("response = \(response!)")
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    DispatchQueue.main.async {
                        
                        if let parseJSON = json {
                            
                            print(parseJSON)
                            let status =   parseJSON["status"] as! String
                            
                            if status == "true"{
                                ACProgressHUD.shared.hideHUD()
                                let dataArray = parseJSON["data"] as AnyObject
                                let userId = dataArray.value(forKey:"ID") as! String
                                print(userId)
                                UserDefaults.standard.set(userId, forKey: "UserId")
                                UserDefaults.standard.set("True", forKey: Key.is_UserLogin)
                                let Home = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
                                self.navigationController?.pushViewController(Home, animated: true)
                            }else{
                                ACProgressHUD.shared.hideHUD()
                                let alert = UIAlertController(title: "ERROR", message:"User Name or Password Wrong", preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                            }
                        }
                    }
                }
                catch {
                    ACProgressHUD.shared.hideHUD()
                    
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error)
                }
            }
            task.resume()
        }
    }
    
    //MARK: - Google Login Data Send To Database
    func GoogleLoginDataToDataBase(){
        
        ACProgressHUD.shared.showHUD()
        
        DispatchQueue.global(qos: .background).async {
            
            
            let myUrl = URL(string: GlobalUrl.BaseUrl + "login_with_google.php?");
            print(myUrl!)
            var request = URLRequest(url:myUrl!)
            request.httpMethod = "POST"
            let tokenStr = UserDefaults.standard.value(forKey: "DeviceToken") as? String ?? ""
            let postString = "email=" + self.SocialEmailStr + "&token_id=" + tokenStr + "&full_name=" + self.SocialUserNameStr + "&deviceType=IOS"
            
            let userName = "admin"
            let password = "admin"
            var _: Error? = nil
            let authStr = "\(userName):\(password)"
            let authData: Data? = authStr.data(using: .ascii)
            let authStrData = String(data: authData?.base64EncodedData(options: .endLineWithLineFeed) ?? Data(), encoding: .ascii)
            let authValue = "Basic \(authStrData!)"
            request.addValue(authValue, forHTTPHeaderField: "Authorization")
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                
                if error != nil
                {
                    ACProgressHUD.shared.hideHUD()
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error!)
                    
                    return
                }
                
                print("response = \(response!)")
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    DispatchQueue.main.async {
                        
                        if let parseJSON = json {
                            
                            print(parseJSON)
                            let status =   parseJSON["status"] as! String
                            
                            if status == "true"{
                                ACProgressHUD.shared.hideHUD()
                                let dataArray = parseJSON["data"] as AnyObject
                                let userId = dataArray.value(forKey:"ID") as! String
                                print(userId)
                                UserDefaults.standard.set(userId, forKey: "UserId")
                                UserDefaults.standard.set("True", forKey: Key.is_UserLogin)
                                let Home = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
                                self.navigationController?.pushViewController(Home, animated: true)
                            }else{
                                ACProgressHUD.shared.hideHUD()
                                let alert = UIAlertController(title: "ERROR", message:"User Name or Password Wrong", preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                            }
                        }
                    }
                }
                catch {
                    ACProgressHUD.shared.hideHUD()
                    
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error)
                }
            }
            task.resume()
        }
    }

}
