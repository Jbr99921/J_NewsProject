//
//  ForgotPasswordVC.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 10/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//

import UIKit

class ForgotPasswordVC: UIViewController {
    
    var OtpStr: String = String()
    var EmailStr: String = String()
    
    @IBOutlet var passwordSubmitButton: UIButton!
    @IBOutlet var OTPSubmitButton: UIButton!
    @IBOutlet var emailSubmitButton: UIButton!
    @IBOutlet var confirmPasswordTxt: VCTextField!
    @IBOutlet var passwordTxt: VCTextField!
    @IBOutlet var OTPTxt: VCTextField!
    @IBOutlet var emailTxt: VCTextField!
    
    @IBOutlet var passwordHolderView: UIView!
    @IBOutlet var OTPHolderView: UIView!
    @IBOutlet var EnterEmailHolderView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        EnterEmailHolderView.isHidden = false
        OTPHolderView.isHidden = true
        passwordHolderView.isHidden = true
        
        passwordSubmitButton.layer.cornerRadius =  passwordSubmitButton.frame.size.height / 2
        OTPSubmitButton.layer.cornerRadius =  OTPSubmitButton.frame.size.height / 2
        emailSubmitButton.layer.cornerRadius =  emailSubmitButton.frame.size.height / 2
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Button Action Method

    @IBAction func backButtonClicked(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    @IBAction func emailSubmitButtonClicked(_ sender: Any) {
        EmailStr = emailTxt.text ?? ""
        SendOtpToEmail()
    }
    @IBAction func OTPSubmitButtonClicked(_ sender: Any) {
        if OTPTxt.text == OtpStr{
            OTPHolderView.isHidden = true
            passwordHolderView.isHidden = false
        }else{
            let alert = UIAlertController(title: "Alert", message: "Entered Otp was not match", preferredStyle:     UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    @IBAction func passwordButtonClicked(_ sender: Any) {
        if passwordTxt.text == confirmPasswordTxt.text{
            ResetPassword()
        }else{
            let alert = UIAlertController(title: "Alert", message: "Pawword not match", preferredStyle:     UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    func SendOtpToEmail(){
        
        ACProgressHUD.shared.showHUD()
        
        DispatchQueue.global(qos: .background).async {
            //http://easydatasearch.com/easydata1/News/apis/forgot_password.php?email=archirayan1@gmail.com
            
            let myUrl = URL(string: GlobalUrl.BaseUrl + "forgot_password.php?");
            var request = URLRequest(url:myUrl!)
            request.httpMethod = "POST"
            
            let postString = "email=" + self.emailTxt.text!
            
            let userName = "admin"
            let password = "admin"
            var _: Error? = nil
            let authStr = "\(userName):\(password)"
            let authData: Data? = authStr.data(using: .ascii)
            let authStrData = String(data: authData?.base64EncodedData(options: .endLineWithLineFeed) ?? Data(), encoding: .ascii)
            let authValue = "Basic \(authStrData!)"
            request.addValue(authValue, forHTTPHeaderField: "Authorization")
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                
                if error != nil
                {
                    ACProgressHUD.shared.hideHUD()
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error!)
                    
                    return
                }
                
                print("response = \(response!)")
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    DispatchQueue.main.async {
                        
                        if let parseJSON = json {
                            
                            print(parseJSON)
                            let status =   parseJSON["status"] as! String
                            
                            if status == "true"{
                                ACProgressHUD.shared.hideHUD()
                                let data = parseJSON["data"] as AnyObject
                                self.OtpStr = data .value(forKey: "otp") as? String ?? ""
                                print(self.OtpStr)
                                self.EnterEmailHolderView.isHidden = true
                                self.OTPHolderView.isHidden = false
                            }else{
                                ACProgressHUD.shared.hideHUD()
                                let alert = UIAlertController(title: "ERROR", message:"Enter Correct Email Address", preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                                
                            }
                        }
                    }
                }
                catch {
                    ACProgressHUD.shared.hideHUD()
                    
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error)
                }
            }
            task.resume()
        }
    }
    func ResetPassword(){
        
        ACProgressHUD.shared.showHUD()
        
        DispatchQueue.global(qos: .background).async {
            //http://easydatasearch.com/easydata1/News/apis/reset_password.php?email=archirayan1@gmail.com&&opt=111&&new_password=2222
            
            let myUrl = URL(string: GlobalUrl.BaseUrl + "reset_password.php?");
            var request = URLRequest(url:myUrl!)
            request.httpMethod = "POST"
            
            let postString = "email=" + self.EmailStr + "&new_password=" + self.passwordTxt.text!
            
            let userName = "admin"
            let password = "admin"
            var _: Error? = nil
            let authStr = "\(userName):\(password)"
            let authData: Data? = authStr.data(using: .ascii)
            let authStrData = String(data: authData?.base64EncodedData(options: .endLineWithLineFeed) ?? Data(), encoding: .ascii)
            let authValue = "Basic \(authStrData!)"
            request.addValue(authValue, forHTTPHeaderField: "Authorization")
            
            request.httpBody = postString.data(using: String.Encoding.utf8);
            let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
                
                if error != nil
                {
                    ACProgressHUD.shared.hideHUD()
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error!)
                    
                    return
                }
                
                print("response = \(response!)")
                
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    DispatchQueue.main.async {
                        
                        if let parseJSON = json {
                            
                            print(parseJSON)
                            let status =   parseJSON["status"] as! String
                            
                            if status == "true"{
                                ACProgressHUD.shared.hideHUD()
                                let SignIN = self.storyboard?.instantiateViewController(withIdentifier: "SignINVC") as! SignINVC
                                SignIN.isComeFrom = "ForgotPaasword"
                                self.navigationController?.pushViewController(SignIN, animated: true)
                            }else{
                                ACProgressHUD.shared.hideHUD()
                                let alert = UIAlertController(title: "ERROR", message:"Enter Correct Email Address", preferredStyle:     UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                                
                            }
                        }
                    }
                }
                catch {
                    ACProgressHUD.shared.hideHUD()
                    
                    let alert = UIAlertController(title: "", message: "Something went wrong", preferredStyle:     UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    print(error)
                }
            }
            task.resume()
        }
    }

}
