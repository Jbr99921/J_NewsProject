//
//  Global.swift
//  NewsPaper
//
//  Created by Dilip Bakotiya on 08/12/18.
//  Copyright © 2018 Archirayan. All rights reserved.
//

import Foundation

struct GlobalUrl {
    static let BaseUrl = "http://hire-people.com/host2/news_wp/api/"
    //Mark : old API http://hire-people.com/host2/News/apis/
}

struct Key {
    static let is_UserLogin = "UserLogin"
}

