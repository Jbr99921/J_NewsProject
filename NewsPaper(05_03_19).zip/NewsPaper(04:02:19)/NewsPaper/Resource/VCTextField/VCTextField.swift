//
//  VCTextField.swift
//  Vikram Chaudhary
//
//  Created by apple on 4/23/18.
//  Copyright © 2018 cme. All rights reserved.
//

import Foundation
import UIKit

public protocol VCTextFieldDelegate: class {
    
    func VCTextFieldShouldReturn(_ textField: UITextField)
    
    func VCTextField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String)
    
    func VCTextFieldShouldBeginEditing(_ textField: UITextField)
    
    func VCTextFieldShouldClear(_ textField: UITextField)
    
    func VCTextFieldShouldEndEditing(_ textField: UITextField)
    
    func VCTextFieldDidBeginEditing(_ textField: UITextField)
    
    func VCTextFieldDidEndEditing(_ textField: UITextField)
}

extension VCTextFieldDelegate {
    
    func VCTextFieldShouldReturn(_ textField: UITextField) {}
    
    func VCTextField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) {}
    
    func VCTextFieldShouldBeginEditing(_ textField: UITextField) {}
    
    func VCTextFieldShouldClear(_ textField: UITextField) {}
    
    func VCTextFieldShouldEndEditing(_ textField: UITextField) {}
    
    func VCTextFieldDidBeginEditing(_ textField: UITextField) {}
    
    func VCTextFieldDidEndEditing(_ textField: UITextField) {}
}

//@IBDesignable
class VCTextField: UITextField, UITextFieldDelegate {
    
    @IBInspectable var txtBorderWidth: CGFloat = 0
    @IBInspectable var txtBorderColor: UIColor = UIColor.clear
    
    @IBInspectable var placeHolderColor: UIColor? = UIColor.black
    @IBInspectable var activePlaceHolderColor: UIColor?  = UIColor.white
    
    
    @IBInspectable var deviderColor: UIColor? = UIColor.black
    @IBInspectable var activeDeviderColor: UIColor?  = UIColor.white
    @IBInspectable var deviderHeight: CGFloat = 0
    
    @IBInspectable var insetX: CGFloat = 0
    @IBInspectable var insetY: CGFloat = 0
    @IBInspectable var maxInputValue: Int = 200
    
    @IBInspectable var txtCornerRadius: CGFloat = 0
    @IBInspectable var topCornerRadious: Bool = false
    @IBInspectable var bottomCornerRadious: Bool = false
    
    @IBInspectable var floatingTextField: Bool = false
    @IBInspectable var resignOnReturn: Bool = false
    var titleFontSize: CGFloat = UIDevice.current.userInterfaceIdiom == .pad ? 23 : 13
    
    @IBInspectable var leftImage : UIImage? = UIImage()
    
    fileprivate var corners = UIRectCorner()
    
    var vcTextFieldDelegate: VCTextFieldDelegate?
    
    
    @IBInspectable var shouldAlignRightOnArabic : Bool = true{
        didSet{
            // if true then it is defult true to not need to set anything
            guard !shouldAlignRightOnArabic else { return }
            textAlignment = .center
        }
    }
    
    
    override var text: String? {
        didSet{
//            checkForLanguageDirection()
//            guard text != text? else { return }
//            text = text?
        }
    }
    
    override var placeholder: String? {
        didSet{
//            checkForLanguageDirection()
//            guard placeholder != placeholder? else { return }
//            placeholder = placeholder?
        }
    }
    
    func checkForLanguageDirection(){
        guard shouldAlignRightOnArabic else { return }
        
        //        print("\(text) = \(shouldAlignRightOnArabic ? "True" : "False")")
//        textAlignment = VCLangauageManager.sharedInstance.isLanguageEnglish() ? .left : .right
    }
    
    fileprivate func initTitleLabel() {
        placeholder = placeholder ?? ""
        if floatingTextField && text != "" {
            updateTitleLabel(true)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initTitleLabel()
        self.borderStyle = .none
        if topCornerRadious && bottomCornerRadious {
            corners = [.allCorners]
        } else if topCornerRadious {
            corners = [.topLeft, .topRight]
        }else if bottomCornerRadious {
            corners = [.bottomRight, .bottomLeft]
        } else {
            corners = [.allCorners]
        }
        setBorderAndCornerRadious()
        self.initFloatingLabel()
        createTitleLabel()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initTitleLabel()
        self.borderStyle = .none
        if topCornerRadious && bottomCornerRadious {
            corners = [.allCorners]
        } else if topCornerRadious {
            corners = [.topLeft, .topRight]
        }else if bottomCornerRadious {
            corners = [.bottomRight, .bottomLeft]
        } else {
            corners = [.allCorners]
        }
        setBorderAndCornerRadious()
        self.initFloatingLabel()
        createTitleLabel()
    }
    
    override func draw(_ rect: CGRect) {
        self.borderStyle = .none
        initTitleLabel()
        if topCornerRadious && bottomCornerRadious {
            corners = [.allCorners]
        } else if topCornerRadious {
            corners = [.topLeft, .topRight]
        }else if bottomCornerRadious {
            corners = [.bottomRight, .bottomLeft]
        } else {
            corners = [.allCorners]
        }
        if !floatingTextField {
            self.makeBorderWithCornerRadius(radius: txtCornerRadius, borderColor: txtBorderColor, borderWidth: txtBorderWidth)
        }
        setBorderAndCornerRadious()
        self.initFloatingLabel()
    }
    
    override func setNeedsLayout() {
        super.setNeedsLayout()
        setNeedsDisplay()
    }
    
    override func prepareForInterfaceBuilder() {
        self.borderStyle = .none
        setBorderAndCornerRadious()
        self.initFloatingLabel()
    }
    
    var placeHplderFloating = UILabel()
    var bottomLine = CALayer()
    
    override func awakeFromNib() {
        NotificationCenter.default.addObserver(self, selector: #selector(rotated), name: NSNotification.Name.UIDeviceOrientationDidChange, object: nil)
        self.delegate = self
        self.borderStyle = .none
        self.addTarget(self, action: #selector(setActivePlaceHolder), for: .editingChanged)
        self.addTarget(self, action: #selector(setSimplePlaceHolder), for: .editingDidEnd)
        setBorderAndCornerRadious()
    }
    
    @objc func rotated() {
        setBorderAndCornerRadious()
        self.initFloatingLabel()
        createTitleLabel()
    }
    
    override open func textRect(forBounds bounds: CGRect) -> CGRect {
        let superRect = super.textRect(forBounds: bounds)
        let titleHeight = self.titleHeight()
        
        let rect = CGRect(
            x: insetX,
            y: titleHeight  - insetY,
            width: superRect.size.width,
            height: superRect.size.height - titleHeight - deviderHeight
        )
        return rect
    }
    
    /**
     Calculate the rectangle for the textfield when it is being edited
     - parameter bounds: The current bounds of the field
     - returns: The rectangle that the textfield should render in
     */
    override open func editingRect(forBounds bounds: CGRect) -> CGRect {
        let superRect = super.editingRect(forBounds: bounds)
        let titleHeight = self.titleHeight()
        
        let rect = CGRect(
            x: insetX,
            y: titleHeight  - insetY,
            width: superRect.size.width,
            height: superRect.size.height - titleHeight - deviderHeight
        )
        return rect
    }
    
    /**
     Calculate the rectangle for the placeholder
     - parameter bounds: The current bounds of the placeholder
     - returns: The rectangle that the placeholder should render in
     */
    override open func placeholderRect(forBounds bounds: CGRect) -> CGRect {
        let rect = CGRect(
            x: insetX,
            y: titleHeight() - insetY,
            width: bounds.size.width,
            height: bounds.size.height - titleHeight() - deviderHeight
        )
        return rect
    }
    
    // MARK: - Set Max Input Range
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        vcTextFieldDelegate?.VCTextField(textField, shouldChangeCharactersIn: range, replacementString: string)
        if textField == self {
            let charsLimit = maxInputValue
            let startingLength = textField.text?.count ?? 0
            let lengthToAdd = string.count
            let lengthToReplace =  range.length
            let newLength = startingLength + lengthToAdd - lengthToReplace
            return newLength <= charsLimit
        }
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if resignOnReturn {
            self.resignFirstResponder()
        }
        setSimplePlaceHolder()
        if floatingTextField {
            titleLabel.textColor = self.placeHolderColor
        }
        vcTextFieldDelegate?.VCTextFieldShouldReturn(textField)
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        vcTextFieldDelegate?.VCTextFieldDidBeginEditing(textField)
        setActivePlaceHolder()
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        vcTextFieldDelegate?.VCTextFieldDidEndEditing(textField)
        setSimplePlaceHolder()
        if floatingTextField {
            titleLabel.textColor = self.placeHolderColor
        }
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        vcTextFieldDelegate?.VCTextFieldShouldBeginEditing(textField)
        return true;
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        vcTextFieldDelegate?.VCTextFieldShouldClear(textField)
        return true;
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        vcTextFieldDelegate?.VCTextFieldShouldEndEditing(textField)
        return true;
    }
    
    private func setBorderAndCornerRadious() {
//        updateTextAligment()
        //        IQKeyboardManager.shared.enable = true
        //        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
        //        IQKeyboardManager.shared.keyboardDistanceFromTextField = 45
        if leftImage?.size.width != 0 {
            insetX = 30
            leftViewMode = .always
            let imageView = UIImageView(frame: CGRect(x: 0, y: 3, width: 20, height: 20))
            imageView.contentMode = .scaleAspectFit
            imageView.image = leftImage
            imageView.tintColor = tintColor
            let view = UIView(frame : CGRect(x: 0, y: 0, width: 25, height: 20))
            view.addSubview(imageView)
            leftView = view
        } else {
            self.bounds.insetBy(dx: insetX, dy: insetY)
            leftViewMode = .never
        }
        setCornerRadious()
        if self.isEditing {
            setActivePlaceHolder()
        } else {
            setSimplePlaceHolder()
        }
    }
    
    // MARK: -  Corner Radious
    private func setCornerRadious() {
        
        // Create the shape layer and set its path
        
        //Add this layer to give border.
        
    }
    
    private func setRoundCorners(corners: UIRectCorner) {
        let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: txtCornerRadius, height: txtCornerRadius))
        let maskLayer = CAShapeLayer()
        maskLayer.frame = self.bounds
        maskLayer.path = path.cgPath
        self.layer.mask = maskLayer
        
    }
    
    func makeBorderWithCornerRadius(radius: CGFloat, borderColor: UIColor, borderWidth: CGFloat) {
        let rect = self.bounds;
        
        let maskPath = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        
        // Create the shape layer and set its path
        let maskLayer = CAShapeLayer()
        maskLayer.frame = rect
        maskLayer.path  = maskPath.cgPath
        
        // Set the newly created shape layer as the mask for the view's layer
        self.layer.mask = maskLayer
        
        //Create path for border
        let borderPath = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        
        // Create the shape layer and set its path
        let borderLayer = CAShapeLayer()
        
        borderLayer.frame       = rect
        borderLayer.path        = borderPath.cgPath
        borderLayer.strokeColor = txtBorderColor.cgColor
        borderLayer.fillColor   = UIColor.clear.cgColor
        borderLayer.lineWidth   = txtBorderWidth * UIScreen.main.scale
        
        //Add this layer to give border.
        self.layer.addSublayer(borderLayer)
    }
    
    
    
    func initFloatingLabel() {
        if !self.isEditing {
            self.tintColor = placeHolderColor
            bottomLine = CALayer()
            bottomLine.frame = CGRect(x: 0, y: self.frame.size.height - deviderHeight, width:  self.frame.size.width, height: deviderHeight)
            bottomLine.borderWidth = deviderHeight
            self.layer.cornerRadius = 0
            self.borderStyle = .none
            self.layer.addSublayer(bottomLine)
            bottomLine.borderColor = deviderColor?.cgColor
            self.layer.masksToBounds = true
        }
    }
    
    @objc private func setSimplePlaceHolder() {
        self.tintColor = placeHolderColor
        self.textColor = placeHolderColor
        if floatingTextField {
            updateTitleLabel(true)
        }
        self.attributedPlaceholder = NSAttributedString(string:self.placeholder != nil ? self.placeholder! : "", attributes:[.foregroundColor: placeHolderColor!])
    }
    
    @objc private func setActivePlaceHolder() {
        self.tintColor = activePlaceHolderColor
        self.textColor = activePlaceHolderColor
        self.attributedPlaceholder = NSAttributedString(string:self.placeholder != nil ? self.placeholder! : "", attributes:[.foregroundColor: activePlaceHolderColor!])
        
        self.bottomLine.borderColor = self.activeDeviderColor?.cgColor
        self.layer.masksToBounds = true
        if floatingTextField {
            updateTitleLabel(true)
        }
    }
    
    
    open var isLTRLanguage: Bool = UIApplication.shared.userInterfaceLayoutDirection == .leftToRight {
        didSet {
//            updateTextAligment()
        }
    }
    
//    fileprivate func updateTextAligment() {
//        if VCLangauageManager.sharedInstance.isLanguageEnglish() {
//            textAlignment = .left
//        } else {
//            textAlignment = .right
//        }
//    }
//
//    fileprivate func updatetextAlignmentForTitle() {
//        if VCLangauageManager.sharedInstance.isLanguageEnglish() {
//            titleLabel.textAlignment = .left
//        } else {
//            titleLabel.textAlignment = .right
//        }
//    }
    
    open var titleLabel: UILabel!
    
    // MARK: Animation timing
    
    /// The value of the title appearing duration
    @objc dynamic open var titleFadeInDuration: TimeInterval = 0.2
    /// The value of the title disappearing duration
    @objc dynamic open var titleFadeOutDuration: TimeInterval = 0.3
    
    // MARK: create components
    
    fileprivate func createTitleLabel() {
        let titleLabel = UILabel()
        titleLabel.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        titleLabel.font = UIFont.init(name: (self.font?.fontName)!, size: titleFontSize)
        titleLabel.alpha = 0.0
        titleLabel.textColor = self.placeHolderColor
        addSubview(titleLabel)
        self.titleLabel = titleLabel
        updateTitleLabel()
    }
    
    func updateTitleLabel() {
        if floatingTextField && text != "" {
            updateTitleLabel(true)
        }
    }
    
    fileprivate func updateTitleLabel(_ animated: Bool = false) {
        
//        updatetextAlignmentForTitle()
        if self.isEditing {
            titleLabel.textColor = activePlaceHolderColor
        } else {
            titleLabel.textColor = placeHolderColor
        }
        titleLabel.text = self.placeholder
        titleLabel.font = UIFont.init(name: (self.font?.fontName)!, size: titleFontSize)
        self.setTitleVisible(self.text != "" ? true : false)
    }
    
    fileprivate var _titleVisible: Bool = false
    
    open func isTitleVisible() -> Bool {
        return hasText || _titleVisible
    }
    
    open func setTitleVisible(
        _ titleVisible: Bool,
        animated: Bool = false,
        animationCompletion: ((_ completed: Bool) -> Void)? = nil
        )   {
        if  _titleVisible == titleVisible {
            return
        }
        _titleVisible = titleVisible
        updateTitleVisibility(animated, completion: animationCompletion)
    }
    
    open func titleHeight() -> CGFloat {
        //        if let titleLabel = titleLabel,
        //            let font = titleLabel.font {
        //            return font.lineHeight
        //        }
        return 18.0
    }
    
    open func titleLabelRectForBounds(_ bounds: CGRect, editing: Bool) -> CGRect {
        let alignX: CGFloat = leftImage?.size.width != 0 ? 30.0 : insetX
        if editing {
            return CGRect(x: alignX, y: 0, width: bounds.size.width, height: titleHeight())
        }
        return CGRect(x: alignX, y: titleHeight(), width: bounds.size.width, height: titleHeight())
    }
    
    fileprivate func updateTitleVisibility(_ animated: Bool = false, completion: ((_ completed: Bool) -> Void)? = nil) {
        let alpha: CGFloat = isTitleVisible() ? 1.0 : 0.0
        let frame: CGRect = titleLabelRectForBounds(bounds, editing: isTitleVisible())
        let updateBlock = { () -> Void in
            self.titleLabel.alpha = alpha
            self.titleLabel.frame = frame
        }
        if animated {
            let animationOptions: UIViewAnimationOptions = .curveEaseOut
            let duration = isTitleVisible() ? titleFadeInDuration : titleFadeOutDuration
            UIView.animate(withDuration: duration, delay: 0, options: animationOptions, animations: { () -> Void in
                updateBlock()
            }, completion: completion)
        } else {
            updateBlock()
            completion?(true)
        }
    }
    
}
